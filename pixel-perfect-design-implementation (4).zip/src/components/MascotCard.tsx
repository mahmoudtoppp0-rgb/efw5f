import { useEffect, useRef, useState, type KeyboardEvent } from "react";
import type { MascotItem } from "../data/mascots";
import { MascotBadgeIcon } from "./HesiCoreParts";
import MascotRenderer from "./MascotRenderer";

export type LanguageMode = "bilingual" | "ar" | "en";

interface MascotCardProps {
  item: MascotItem;
  index: number;
  lang: LanguageMode;
  onInspect: (item: MascotItem) => void;
}

export default function MascotCard({
  item,
  index,
  lang,
  onInspect,
}: MascotCardProps) {
  const cardRef = useRef<HTMLElement>(null);
  const [inView, setInView] = useState(true);
  const [hasEntered, setHasEntered] = useState(false);
  const [reactionCount, setReactionCount] = useState(0);
  const [showToast, setShowToast] = useState(false);
  const toastTimerRef = useRef<number | null>(null);

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
        if (entry.isIntersecting) {
          setHasEntered(true);
        }
      },
      { threshold: 0.08, rootMargin: "60px 0px" }
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    return () => {
      if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    };
  }, []);

  const triggerReaction = () => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setReactionCount((c) => c + 1);
    setShowToast(true);

    toastTimerRef.current = window.setTimeout(() => {
      setShowToast(false);
    }, 3400);
  };

  const handleStageKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      triggerReaction();
    }
  };

  const isEmotional = item.category === "emotional";

  return (
    <article
      ref={cardRef}
      data-in-view={inView ? "true" : "false"}
      style={{ transitionDelay: `${(index % 6) * 55}ms` }}
      className={`mascot-card group relative flex flex-col justify-between rounded-[28px] border transition-all duration-500 ${
        hasEntered ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
      } ${
        isEmotional
          ? "border-[#D9EFE4] bg-gradient-to-b from-[#F4FAFC] via-[#F2F9FB] to-[#ECF8F3] p-5 shadow-[0_10px_30px_-12px_rgba(15,29,58,0.07)] hover:-translate-y-1.5 hover:border-[#9CE0B9] hover:shadow-[0_22px_44px_-14px_rgba(22,163,74,0.18)]"
          : "border-[#DCEEE3] bg-white p-6 shadow-[0_12px_34px_-14px_rgba(15,29,58,0.08)] hover:-translate-y-1.5 hover:border-[#86EFAC] hover:shadow-[0_24px_48px_-14px_rgba(22,163,74,0.18)]"
      }`}
    >
      {/* Top Meta Bar */}
      <div className="flex items-center justify-between gap-2">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold tracking-wide"
          style={{
            backgroundColor: item.accentBg,
            color: item.accentColor,
          }}
        >
          <span
            className="h-2 w-2 rounded-full"
            style={{ backgroundColor: item.accentColor }}
          />
          {lang === "ar" ? item.badgeTextAr : item.badgeTextEn}
        </span>

        {item.planHighlight ? (
          <span className="rounded-full bg-[#F1F5F9] px-2.5 py-1 text-[11px] font-medium text-[#334155]">
            {item.planHighlight}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-[#ECFDF3] px-2.5 py-0.5 text-[10px] font-bold text-[#15803D]">
            <span className="h-1.5 w-1.5 rounded-full bg-[#22C55E]" />
            60 FPS Rig
          </span>
        )}
      </div>

      {/* Interactive 60fps Mascot Stage (Clickable, Pointer-Responsive & Keyboard Accessible) */}
      <div
        role="button"
        tabIndex={0}
        onClick={triggerReaction}
        onKeyDown={handleStageKeyDown}
        aria-label={`${item.nameEn} (${item.nameAr}) mascot — move pointer to interact or press Enter to trigger ${item.reactionCue}`}
        className="relative my-2 flex aspect-[10/9] w-full cursor-pointer items-center justify-center rounded-2xl outline-none focus-visible:ring-3 focus-visible:ring-[#16A34A] focus-visible:ring-offset-2"
      >
        <div className="mascot-stage-inner h-full w-full">
          <MascotRenderer
            id={item.id}
            phaseOffset={index * 0.65}
            reactionTrigger={reactionCount}
            inView={inView}
            className="h-full w-full"
          />
        </div>

        {/* Floating Non-Layout-Shifting Learner Toast on Reaction */}
        <div
          aria-live="polite"
          className={`pointer-events-none absolute inset-x-2 bottom-2 z-20 rounded-xl border border-[#86EFAC] bg-[#0F1D3A]/95 px-3.5 py-2.5 text-xs text-white shadow-lg backdrop-blur-md transition-all duration-300 ${
            showToast
              ? "translate-y-0 scale-100 opacity-100"
              : "translate-y-2 scale-95 opacity-0"
          }`}
        >
          <div className="flex items-center justify-between gap-2 text-[11px] font-semibold text-[#86EFAC]">
            <span>✦ {item.reactionCue}</span>
            <span className="font-arabic">{item.nameAr}</span>
          </div>
          <p className="mt-1 leading-snug text-white/95">
            {lang === "ar" ? item.learnerToastAr : item.learnerToastEn}
          </p>
        </div>
      </div>

      {/* Authentic Reference Image 2 Bottom Pill Badge */}
      <div className="mx-auto w-full max-w-[310px]">
        <div className="flex items-center justify-between gap-3 rounded-full border border-[#BDE8D0] bg-gradient-to-r from-[#E6F7EE] via-[#F2FBF6] to-[#E6F7EE] px-3.5 py-2 shadow-xs transition-colors group-hover:border-[#6EE7B7]">
          <MascotBadgeIcon
            type={item.iconType}
            accentColor={item.category === "subscription" ? item.accentColor : "#0D7A4E"}
          />

          <div className="flex flex-1 flex-col items-center justify-center text-center leading-tight">
            {lang === "bilingual" && (
              <>
                <div className="flex items-center gap-2">
                  <span className="font-display text-base font-bold text-[#0F1D3A]">
                    {item.nameEn}
                  </span>
                  <span className="text-xs text-[#94A3B8]">•</span>
                  <span className="font-arabic text-base font-bold text-[#0F1D3A]" dir="rtl">
                    {item.nameAr}
                  </span>
                </div>
                <div className="mt-0.5 flex flex-wrap items-center justify-center gap-1.5 text-xs font-medium text-[#334E68]">
                  <span>{item.subtitleEn}</span>
                  <span className="text-[#94A3B8]">/</span>
                  <span className="font-arabic" dir="rtl">
                    {item.subtitleAr}
                  </span>
                </div>
              </>
            )}

            {lang === "ar" && (
              <div dir="rtl" className="font-arabic">
                <p className="text-lg font-extrabold text-[#0F1D3A]">{item.nameAr}</p>
                <p className="text-xs font-semibold text-[#334E68]">{item.subtitleAr}</p>
              </div>
            )}

            {lang === "en" && (
              <div>
                <p className="font-display text-base font-bold text-[#0F1D3A]">
                  {item.nameEn}
                </p>
                <p className="text-xs font-medium text-[#334E68]">{item.subtitleEn}</p>
              </div>
            )}
          </div>

          <div className="w-4 shrink-0" aria-hidden="true" />
        </div>
      </div>

      {/* Description & Action Controls */}
      <div className="mt-4 border-t border-[#E2F2EA] pt-3.5">
        <p
          dir={lang === "ar" ? "rtl" : "ltr"}
          className={`text-xs leading-relaxed text-[#475569] ${
            lang === "ar" ? "font-arabic text-sm" : ""
          }`}
        >
          {lang === "ar" ? item.descriptionAr : item.descriptionEn}
        </p>

        <div className="mt-3 flex items-center justify-between gap-2">
          <button
            type="button"
            onClick={triggerReaction}
            className="inline-flex items-center gap-1.5 rounded-lg bg-[#ECFDF3] px-3 py-1.5 text-xs font-semibold text-[#0D7A3E] transition-colors hover:bg-[#D1FAE5] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
          >
            <span aria-hidden="true">⚡</span>
            {lang === "ar" ? "تفاعل لحظي" : "Play Reaction"}
          </button>

          <button
            type="button"
            onClick={() => onInspect(item)}
            className="inline-flex items-center gap-1.5 rounded-lg border border-[#CBD5E1] bg-white px-3 py-1.5 text-xs font-semibold text-[#1E293B] transition-colors hover:border-[#16A34A] hover:text-[#16A34A] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
          >
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden="true">
              <polygon points="12 2 2 7 12 12 22 7 12 2" />
              <polyline points="2 17 12 22 22 17" />
              <polyline points="2 12 12 17 22 12" />
            </svg>
            {lang === "ar" ? "فحص الطبقات" : "Inspect Layers"}
          </button>
        </div>
      </div>
    </article>
  );
}
