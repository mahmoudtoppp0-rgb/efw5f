import { useEffect, useState } from "react";
import type { LanguageMode } from "./MascotCard";
import { animationEngine60fps } from "../utils/animationEngine60fps";

export function HesiBrandMark({ size = 48 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 80 86"
      role="img"
      aria-label="Hesi mascot brand mark"
      className="shrink-0 drop-shadow-xs"
    >
      <defs>
        <linearGradient id="hesi-logo-body" x1="0.15" y1="0" x2="0.85" y2="1">
          <stop offset="0%" stopColor="#4ADE80" />
          <stop offset="45%" stopColor="#16A34A" />
          <stop offset="100%" stopColor="#096328" />
        </linearGradient>
        <linearGradient id="hesi-logo-top" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#86EFAC" />
          <stop offset="100%" stopColor="#22C55E" />
        </linearGradient>
      </defs>
      {/* Main Shield Gem */}
      <path
        d="M 40 3 C 43 3 45 4 48 6 L 71 21 C 74 23 76 27 76 32 L 76 52 C 76 58 73 63 68 67 L 46 81 C 42 84 38 84 34 81 L 12 67 C 7 63 4 58 4 52 L 4 32 C 4 27 6 23 9 21 L 32 6 C 35 4 37 3 40 3 Z"
        fill="url(#hesi-logo-body)"
      />
      {/* Top Bevel Facet */}
      <path
        d="M 40 3 L 8 23 Q 40 19 72 23 Z"
        fill="url(#hesi-logo-top)"
        opacity="0.85"
      />
      <path
        d="M 40 3 L 22 22 M 40 3 L 58 22"
        stroke="#BBF7D0"
        strokeWidth="1.3"
        strokeLinecap="round"
      />
      {/* White Visor */}
      <rect x="19" y="25" width="42" height="17" rx="5.5" fill="#FFFFFF" />
      {/* Black Sensor Eye */}
      <rect x="34" y="25.5" width="12" height="14" rx="3.2" fill="#0B1320" />
      <circle cx="37.8" cy="29.5" r="1.6" fill="#FFFFFF" />
      {/* Bottom Yellow-Lime Diamond */}
      <polygon points="40,72 44,76 40,80 36,76" fill="#FACC15" />
    </svg>
  );
}

interface HesiHeaderLockupProps {
  lang: LanguageMode;
  onChangeLang: (lang: LanguageMode) => void;
  reducedMotion: boolean;
  onToggleReducedMotion: () => void;
  speed: number;
  onChangeSpeed: (speed: number) => void;
}

export default function HesiHeaderLockup({
  lang,
  onChangeLang,
  reducedMotion,
  onToggleReducedMotion,
  speed,
  onChangeSpeed,
}: HesiHeaderLockupProps) {
  const [fps, setFps] = useState(60);

  useEffect(() => {
    return animationEngine60fps.subscribeFps(setFps);
  }, []);

  return (
    <header className="sticky top-0 z-40 border-b border-[#D8EFE2] bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
        {/* Authentic Reference Image 2 Lockup: Hesi Icon + "Hesi" | "تعبيرات هيسي — كل لحظة ... شعور مختلف" */}
        <a
          href="#top"
          className="group flex items-center gap-3.5 focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
        >
          <HesiBrandMark size={46} />
          <span className="font-display text-3xl font-extrabold tracking-tight text-[#0F1D3A]">
            Hesi
          </span>
          <span className="h-9 w-px bg-[#CBD5E1]" aria-hidden="true" />
          <div className="flex flex-col justify-center" dir="rtl">
            <span className="font-arabic text-lg font-extrabold leading-tight text-[#0F1D3A]">
              تعبيرات هيسي
            </span>
            <span className="font-arabic text-xs font-semibold text-[#334E68]">
              كل لحظة ... شعور مختلف
            </span>
          </div>
        </a>

        {/* Primary Section Navigation */}
        <nav
          aria-label="Mascot sections"
          className="hidden items-center gap-5 text-sm font-semibold text-[#253858] xl:flex"
        >
          <a href="#subscription-mascots" className="transition-colors hover:text-[#16A34A]">
            Subscription (4)
          </a>
          <a href="#emotional-mascots" className="transition-colors hover:text-[#16A34A]">
            Emotional States (6)
          </a>
          <a href="#scenario-simulator" className="transition-colors hover:text-[#16A34A]">
            60fps Rig Simulator
          </a>
        </nav>

        {/* 60fps Telemetry, Speed, Language & Accessibility Controls */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Live 60 FPS Telemetry & Speed Control */}
          {!reducedMotion && (
            <div
              role="group"
              aria-label="60fps animation speed control"
              className="hidden items-center gap-1 rounded-full border border-[#BFE8D1] bg-[#ECFDF3] px-2.5 py-1 text-xs font-bold text-[#0D7A3E] sm:inline-flex"
            >
              <span className="inline-flex items-center gap-1.5 pr-1.5 tabular-nums">
                <span className="h-2 w-2 rounded-full bg-[#22C55E]" />
                {fps} FPS
              </span>
              <span className="h-3.5 w-px bg-[#A7F3D0]" aria-hidden="true" />
              {[0.5, 1, 1.5].map((s) => (
                <button
                  key={s}
                  type="button"
                  onClick={() => onChangeSpeed(s)}
                  className={`rounded-full px-2 py-0.5 text-[11px] font-bold transition-colors ${
                    speed === s
                      ? "bg-[#16A34A] text-white"
                      : "text-[#0D7A3E] hover:bg-[#D1FAE5]"
                  }`}
                >
                  {s}×
                </button>
              ))}
            </div>
          )}

          {/* Language Switcher */}
          <div
            role="group"
            aria-label="Language display mode"
            className="inline-flex rounded-full border border-[#CFEAD9] bg-[#F4FBF7] p-1 text-xs font-semibold"
          >
            {(
              [
                { id: "bilingual", label: "AR + EN" },
                { id: "ar", label: "العربية" },
                { id: "en", label: "English" },
              ] as const
            ).map((opt) => (
              <button
                key={opt.id}
                type="button"
                onClick={() => onChangeLang(opt.id)}
                className={`rounded-full px-2.5 py-1 transition-all ${
                  lang === opt.id
                    ? "bg-[#16A34A] text-white shadow-xs"
                    : "text-[#253858] hover:text-[#16A34A]"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>

          {/* Calm / Reduced Motion Toggle */}
          <button
            type="button"
            onClick={onToggleReducedMotion}
            aria-pressed={reducedMotion}
            className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-semibold transition-all focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
              reducedMotion
                ? "border-[#0F1D3A] bg-[#0F1D3A] text-white"
                : "border-[#CFEAD9] bg-white text-[#253858] hover:border-[#16A34A]"
            }`}
          >
            <span
              className={`h-2 w-2 rounded-full ${
                reducedMotion ? "bg-[#FACC15]" : "bg-[#22C55E]"
              }`}
            />
            {reducedMotion ? "Calm Static: ON" : "60fps Motion: ON"}
          </button>
        </div>
      </div>
    </header>
  );
}
