import { useEffect, useState } from "react";
import { ALL_MASCOTS, type MascotItem } from "../data/mascots";
import { DEFAULT_LAYERS, MascotBadgeIcon, type LayerVisibility } from "./HesiCoreParts";
import MascotRenderer from "./MascotRenderer";
import type { LanguageMode } from "./MascotCard";

interface LivePlaygroundModalProps {
  item: MascotItem | null;
  lang: LanguageMode;
  onClose: () => void;
  onSelectMascot: (item: MascotItem) => void;
}

export default function LivePlaygroundModal({
  item,
  lang,
  onClose,
  onSelectMascot,
}: LivePlaygroundModalProps) {
  const [layers, setLayers] = useState<Required<LayerVisibility>>(DEFAULT_LAYERS);
  const [reactionCount, setReactionCount] = useState(0);

  useEffect(() => {
    setLayers(DEFAULT_LAYERS);
    setReactionCount(0);
  }, [item?.id]);

  useEffect(() => {
    if (!item) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [item, onClose]);

  if (!item) return null;

  const toggleLayer = (key: keyof LayerVisibility) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const resetLayers = () => setLayers(DEFAULT_LAYERS);

  const playReaction = () => {
    setReactionCount((c) => c + 1);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-[#0F1D3A]/60 p-4 backdrop-blur-xs"
      role="dialog"
      aria-modal="true"
      aria-labelledby="inspector-modal-title"
      onClick={onClose}
    >
      <div
        className="relative max-h-[92vh] w-full max-w-4xl overflow-y-auto rounded-3xl border border-[#BFE8D1] bg-white p-6 shadow-2xl sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E2F2EA] pb-4">
          <div className="flex items-center gap-3">
            <MascotBadgeIcon type={item.iconType} accentColor={item.accentColor} />
            <div>
              <div className="flex items-center gap-2.5">
                <h3
                  id="inspector-modal-title"
                  className="font-display text-xl font-bold text-[#0F1D3A]"
                >
                  {item.nameEn}
                </h3>
                <span className="font-arabic text-xl font-bold text-[#16A34A]" dir="rtl">
                  {item.nameAr}
                </span>
                <span className="rounded-full bg-[#ECFDF3] px-2.5 py-0.5 text-xs font-semibold text-[#15803D]">
                  {item.category === "subscription" ? "Subscription Tier" : "Emotional State"}
                </span>
              </div>
              <p className="text-xs text-[#475569]">
                {item.subtitleEn} • <span className="font-arabic">{item.subtitleAr}</span>
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close inspector"
            className="rounded-full border border-[#CBD5E1] p-2 text-[#334155] transition-colors hover:border-[#0F1D3A] hover:bg-[#F8FAFC] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
          >
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2">
              <line x1="18" y1="6" x2="6" y2="18" />
              <line x1="6" y1="6" x2="18" y2="18" />
            </svg>
          </button>
        </div>

        {/* Main Content Grid */}
        <div className="mt-6 grid gap-6 lg:grid-cols-12">
          {/* Left: Live Interactive 60fps Stage */}
          <div className="flex flex-col items-center justify-between rounded-2xl border border-[#D9EFE4] bg-gradient-to-b from-[#F4FAFC] via-[#F2F9FB] to-[#E9F7F0] p-6 lg:col-span-6">
            <div className="flex w-full items-center justify-between text-xs font-semibold text-[#334E68]">
              <span className="inline-flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-[#22C55E]" />
                60 FPS Interactive Stage
              </span>
              <button
                type="button"
                onClick={playReaction}
                className="inline-flex items-center gap-1 rounded-full bg-[#16A34A] px-3 py-1 text-xs font-semibold text-white shadow-xs transition-transform hover:bg-[#15803D] active:scale-95"
              >
                <span>⚡</span> Trigger 60fps Impulse
              </button>
            </div>

            <div
              onClick={playReaction}
              className="my-2 aspect-square w-full max-w-[300px] cursor-pointer"
            >
              <MascotRenderer
                id={item.id}
                layers={layers}
                reactionTrigger={reactionCount}
              />
            </div>

            {/* Live In-App Learner Notification Preview */}
            <div className="w-full rounded-xl border border-[#BFE8D1] bg-white/90 p-3.5 shadow-xs">
              <div className="flex items-center justify-between text-[11px] font-semibold text-[#16A34A]">
                <span>Hesi Companion Message</span>
                <span>{item.reactionCue}</span>
              </div>
              <p
                dir={lang === "ar" ? "rtl" : "ltr"}
                className={`mt-1 text-xs leading-relaxed font-medium text-[#0F1D3A] ${
                  lang === "ar" ? "font-arabic text-sm" : ""
                }`}
              >
                {lang === "ar" ? item.learnerToastAr : item.learnerToastEn}
              </p>
            </div>
          </div>

          {/* Right: Independent SVG Layer Controls & Motion Profile */}
          <div className="flex flex-col justify-between lg:col-span-6">
            <div>
              <div className="flex items-center justify-between">
                <h4 className="font-display text-sm font-bold uppercase tracking-wider text-[#0F1D3A]">
                  Independent SVG Layer Controls
                </h4>
                <button
                  type="button"
                  onClick={resetLayers}
                  className="text-xs font-semibold text-[#16A34A] hover:underline"
                >
                  Show All Layers
                </button>
              </div>
              <p className="mt-1 text-xs text-[#475569]">
                Every Hesi mascot is constructed from genuinely separate SVG groups ({"<g>"}) driven at 60fps. Toggle any layer below to inspect how the artwork and motion are composed:
              </p>

              <div className="mt-3.5 space-y-2">
                {item.layers.map((layer) => {
                  const active = layers[layer.id];
                  return (
                    <button
                      key={layer.id}
                      type="button"
                      onClick={() => toggleLayer(layer.id)}
                      className={`flex w-full items-center justify-between rounded-xl border px-3.5 py-2.5 text-left transition-all ${
                        active
                          ? "border-[#86EFAC] bg-[#F2FBF6] text-[#0F1D3A]"
                          : "border-[#E2E8F0] bg-[#F8FAFC] text-[#64748B] opacity-70"
                      }`}
                    >
                      <div className="pr-3">
                        <div className="flex items-center gap-2 text-xs font-bold">
                          <span
                            className={`h-2.5 w-2.5 rounded-full ${
                              active ? "bg-[#16A34A]" : "bg-[#CBD5E1]"
                            }`}
                          />
                          <span>{layer.label}</span>
                        </div>
                        <p className="mt-0.5 pl-4 text-[11px] text-[#475569]">
                          {layer.description}
                        </p>
                      </div>
                      <span
                        className={`shrink-0 rounded-md px-2 py-0.5 text-[11px] font-semibold ${
                          active
                            ? "bg-[#16A34A] text-white"
                            : "bg-[#E2E8F0] text-[#475569]"
                        }`}
                      >
                        {active ? "Visible" : "Hidden"}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Motion Choreography Spec */}
            <div className="mt-4 rounded-xl border border-[#E2E8F0] bg-[#F8FAFC] p-3.5">
              <p className="text-[11px] font-bold uppercase tracking-wider text-[#334E68]">
                60 FPS Choreography & Secondary Motion Profile
              </p>
              <p className="mt-1 text-xs font-medium text-[#0F1D3A]">{item.motionProfile}</p>
            </div>
          </div>
        </div>

        {/* Bottom Quick Switcher for All 10 Mascots */}
        <div className="mt-6 border-t border-[#E2F2EA] pt-4">
          <p className="mb-2.5 text-xs font-semibold text-[#475569]">
            Switch Mascot State (10 / 10):
          </p>
          <div className="flex flex-wrap gap-2">
            {ALL_MASCOTS.map((m) => {
              const selected = m.id === item.id;
              return (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => onSelectMascot(m)}
                  className={`inline-flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-semibold transition-all ${
                    selected
                      ? "border-[#16A34A] bg-[#16A34A] text-white shadow-xs"
                      : "border-[#DCEEE3] bg-[#F7FCF9] text-[#0F1D3A] hover:border-[#86EFAC]"
                  }`}
                >
                  <span>{m.nameEn}</span>
                  <span className="font-arabic opacity-85" dir="rtl">
                    {m.nameAr}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
