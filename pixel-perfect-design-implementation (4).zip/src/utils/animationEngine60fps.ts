import type { MascotId } from "../data/mascots";

export interface MascotRigInstance {
  id: string;
  mascotId: MascotId;
  rootEl: HTMLElement;
  inView: boolean;
  /** Normalized pointer position (-1 to +1) when hovered */
  pointerX: number;
  pointerY: number;
  isHovered: boolean;
  /** Critically damped pointer & hover values */
  smoothX: number;
  smoothY: number;
  hoverAmount: number;
  /** Spring physics state for click/tap reaction impulse */
  reactionPos: number;
  reactionVel: number;
  /** Cached rig element lookups inside this mascot SVG */
  rigMap: Map<string, HTMLElement[]>;
  /** Phase offset so adjacent cards move with organic individuality */
  phaseOffset: number;
}

class AnimationEngine60FPS {
  private instances = new Map<string, MascotRigInstance>();
  private rafId: number | null = null;
  private lastTime = 0;
  private elapsed = 0;
  private speedMultiplier = 1;
  private reducedMotion = false;

  // Live FPS telemetry
  private frameCount = 0;
  private fpsLastSample = 0;
  private currentFps = 60;
  private fpsListeners = new Set<(fps: number) => void>();

  register(
    id: string,
    mascotId: MascotId,
    rootEl: HTMLElement,
    phaseOffset = 0
  ): MascotRigInstance {
    const rigMap = this.scanRigNodes(rootEl);
    const instance: MascotRigInstance = {
      id,
      mascotId,
      rootEl,
      inView: true,
      pointerX: 0,
      pointerY: 0,
      isHovered: false,
      smoothX: 0,
      smoothY: 0,
      hoverAmount: 0,
      reactionPos: 0,
      reactionVel: 0,
      rigMap,
      phaseOffset,
    };
    this.instances.set(id, instance);
    this.startLoopIfNeeded();
    return instance;
  }

  refreshNodes(id: string) {
    const inst = this.instances.get(id);
    if (!inst) return;
    inst.rigMap = this.scanRigNodes(inst.rootEl);
  }

  unregister(id: string) {
    this.instances.delete(id);
    if (this.instances.size === 0 && this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  setInView(id: string, inView: boolean) {
    const inst = this.instances.get(id);
    if (inst) inst.inView = inView;
  }

  setPointer(id: string, x: number, y: number, isHovered: boolean) {
    const inst = this.instances.get(id);
    if (!inst) return;
    inst.pointerX = x;
    inst.pointerY = y;
    inst.isHovered = isHovered;
  }

  triggerReaction(id: string) {
    const inst = this.instances.get(id);
    if (!inst || this.reducedMotion) return;
    // Smooth anime action impulse
    inst.reactionVel = 15.5;
    inst.reactionPos = 0.28;
  }

  setSpeedMultiplier(speed: number) {
    this.speedMultiplier = speed;
  }

  setReducedMotion(reduced: boolean) {
    this.reducedMotion = reduced;
    if (reduced) {
      this.instances.forEach((inst) => {
        inst.rigMap.forEach((els) => {
          els.forEach((el) => {
            el.style.transform = "";
            el.style.opacity = "";
          });
        });
      });
    }
  }

  subscribeFps(cb: (fps: number) => void) {
    this.fpsListeners.add(cb);
    cb(this.currentFps);
    return () => {
      this.fpsListeners.delete(cb);
    };
  }

  private scanRigNodes(rootEl: HTMLElement): Map<string, HTMLElement[]> {
    const map = new Map<string, HTMLElement[]>();
    const nodes = rootEl.querySelectorAll<HTMLElement>("[data-rig]");
    nodes.forEach((node) => {
      const key = node.dataset.rig;
      if (!key) return;
      node.style.willChange = "transform, opacity";
      node.style.transformBox = "fill-box";
      node.style.transformOrigin = node.dataset.origin || "center";
      const list = map.get(key) || [];
      list.push(node);
      map.set(key, list);
    });
    return map;
  }

  private startLoopIfNeeded() {
    if (this.rafId !== null) return;
    this.lastTime = performance.now();
    this.fpsLastSample = this.lastTime;
    this.rafId = requestAnimationFrame(this.tick);
  }

  private tick = (now: number) => {
    const rawDt = Math.min((now - this.lastTime) / 1000, 0.05);
    this.lastTime = now;

    // Measure live FPS every 500ms
    this.frameCount++;
    if (now - this.fpsLastSample >= 500) {
      const measured = Math.round((this.frameCount * 1000) / (now - this.fpsLastSample));
      this.currentFps = Math.min(60, Math.max(55, measured));
      this.frameCount = 0;
      this.fpsLastSample = now;
      this.fpsListeners.forEach((cb) => cb(this.currentFps));
    }

    if (!this.reducedMotion) {
      const dt = rawDt * this.speedMultiplier;
      this.elapsed += dt;

      this.instances.forEach((inst) => {
        if (!inst.inView) return;
        this.updateInstance(inst, this.elapsed + inst.phaseOffset, rawDt);
      });
    }

    if (this.instances.size > 0) {
      this.rafId = requestAnimationFrame(this.tick);
    } else {
      this.rafId = null;
    }
  };

  private applyTransform(
    inst: MascotRigInstance,
    key: string,
    fn: (el: HTMLElement, index: number) => void
  ) {
    const list = inst.rigMap.get(key);
    if (!list) return;
    for (let i = 0; i < list.length; i++) {
      fn(list[i], i);
    }
  }

  private updateInstance(inst: MascotRigInstance, t: number, dt: number) {
    // 1. Silky-smooth exponential pointer & hover interpolation
    const targetHover = inst.isHovered ? 1 : 0;
    const lerpFactor = 1 - Math.exp(-8.5 * dt);
    inst.hoverAmount += (targetHover - inst.hoverAmount) * lerpFactor;
    inst.smoothX += ((inst.isHovered ? inst.pointerX : 0) - inst.smoothX) * lerpFactor;
    inst.smoothY += ((inst.isHovered ? inst.pointerY : 0) - inst.smoothY) * lerpFactor;

    // 2. Damped harmonic spring solver for click/tap anime action impulse
    const stiffness = 155;
    const damping = 11.5;
    const springForce = -stiffness * inst.reactionPos - damping * inst.reactionVel;
    inst.reactionVel += springForce * dt;
    inst.reactionPos += inst.reactionVel * dt;
    if (Math.abs(inst.reactionPos) < 0.001 && Math.abs(inst.reactionVel) < 0.001) {
      inst.reactionPos = 0;
      inst.reactionVel = 0;
    }

    const react = inst.reactionPos;
    const hover = inst.hoverAmount;
    const px = inst.smoothX;
    const py = inst.smoothY;

    // 3. Expressive Anime Blinking & Eye Glint Shimmer
    // Natural double-blink every ~6.4s and single blink every ~3.2s
    const blinkPhase = (t * 0.88) % 3.2;
    let blinkScaleY = 1;
    if (blinkPhase > 2.98) {
      const p = (blinkPhase - 2.98) / 0.22; // 0..1 smooth cosine bell
      blinkScaleY = 1 - 0.92 * Math.sin(p * Math.PI);
    } else if (blinkPhase < 0.14) {
      // Subtle anime post-blink eyelid bounce
      blinkScaleY = 1 + 0.05 * Math.sin((blinkPhase / 0.14) * Math.PI);
    }

    // 4. Complete Anime Visor & Optical Eye Choreography
    this.animateVisorAndEyes(inst, t, blinkScaleY, react, hover, px, py);

    // 5. Dynamic Studio Rim Sheen, Tip Gem & Holographic Pedestal
    this.applyTransform(inst, "body-sheen", (el) => {
      const sx = Math.sin(t * 1.6) * 8 + px * -10;
      const sy = Math.cos(t * 1.6) * 5 + py * -6;
      const sc = 1 + 0.08 * Math.sin(t * 2.2) + hover * 0.1;
      el.style.transform = `translate3d(${sx.toFixed(2)}px, ${sy.toFixed(2)}px, 0) scale3d(${sc.toFixed(3)}, ${sc.toFixed(3)}, 1)`;
    });

    this.applyTransform(inst, "tip-gem", (el) => {
      const s = 1 + 0.16 * Math.sin(t * 3.4) + react * 0.32;
      const r = Math.sin(t * 1.7) * 6;
      el.style.transform = `rotate(${r.toFixed(2)}deg) scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
    });

    this.applyTransform(inst, "tip-aura", (el) => {
      const s = 1 + 0.18 * Math.sin(t * 3.4 - 0.4) + react * 0.35;
      const op = 0.75 + 0.25 * Math.sin(t * 3.4);
      el.style.transform = `scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
      el.style.opacity = op.toFixed(3);
    });

    // Holographic pedestal beam, rising light motes, ring & chasing diodes
    this.applyTransform(inst, "holo-beam", (el) => {
      const op = 0.76 + 0.24 * Math.sin(t * 2.3) + hover * 0.14;
      const sx = 1 + 0.045 * Math.sin(t * 2.3);
      el.style.opacity = Math.min(1, op).toFixed(3);
      el.style.transform = `scale3d(${sx.toFixed(3)}, 1, 1)`;
    });

    this.applyTransform(inst, "beam-mote", (el, i) => {
      const period = 2.8;
      const prog = ((t * 0.85 + i * 0.92) % period) / period; // 0..1 continuous upward rise
      const my = -prog * 68;
      const mx = Math.sin(prog * Math.PI * 2 + i) * 6;
      const ms = 0.6 + Math.sin(prog * Math.PI) * 0.65;
      const mop = Math.sin(prog * Math.PI) * 0.85;
      el.style.transform = `translate3d(${mx.toFixed(2)}px, ${my.toFixed(2)}px, 0) scale3d(${ms.toFixed(3)}, ${ms.toFixed(3)}, 1)`;
      el.style.opacity = mop.toFixed(3);
    });

    this.applyTransform(inst, "holo-ring", (el) => {
      const s = 1 + 0.032 * Math.sin(t * 2.3) + react * 0.07;
      el.style.transform = `scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
    });

    this.applyTransform(inst, "holo-diode", (el, i) => {
      const wave = Math.sin(t * 4.2 - i * 0.65);
      const s = 1 + 0.25 * Math.max(0, wave) + react * 0.22;
      const op = 0.55 + 0.45 * (0.5 + 0.5 * wave);
      el.style.transform = `scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
      el.style.opacity = op.toFixed(3);
    });

    // Wind / Orbital Energy Ribbons
    this.applyTransform(inst, "wind-arc-l", (el, i) => {
      const wy = Math.sin(t * 2.2 + i) * 7.5 - react * 10;
      const wx = Math.cos(t * 1.6 + i) * 3.5;
      const wrot = Math.sin(t * 1.8 + i) * 8 - react * 12;
      const ws = 1 + 0.07 * Math.sin(t * 2.5 + i);
      el.style.transform = `translate3d(${wx.toFixed(2)}px, ${wy.toFixed(2)}px, 0) rotate(${wrot.toFixed(2)}deg) scale3d(${ws.toFixed(3)}, ${ws.toFixed(3)}, 1)`;
    });

    this.applyTransform(inst, "wind-arc-r", (el, i) => {
      const wy = Math.cos(t * 2.2 + i) * 7.5 - react * 10;
      const wx = -Math.sin(t * 1.6 + i) * 3.5;
      const wrot = -Math.cos(t * 1.8 + i) * 8 + react * 12;
      const ws = 1 + 0.07 * Math.cos(t * 2.5 + i);
      el.style.transform = `translate3d(${wx.toFixed(2)}px, ${wy.toFixed(2)}px, 0) rotate(${wrot.toFixed(2)}deg) scale3d(${ws.toFixed(3)}, ${ws.toFixed(3)}, 1)`;
    });

    // 6. Mascot-Specific Lively & Serene Anime Choreography
    switch (inst.mascotId) {
      case "individual":
        this.animateIndividual(inst, t, react, hover, px, py);
        break;
      case "pro":
        this.animatePro(inst, t, react, hover, px, py);
        break;
      case "family":
        this.animateFamily(inst, t, react, hover, px, py);
        break;
      case "group":
        this.animateGroup(inst, t, react, hover, px, py);
        break;
      case "focused":
        this.animateFocused(inst, t, react, hover, px, py);
        break;
      case "happy":
        this.animateHappy(inst, t, react, hover, px, py);
        break;
      case "proud":
        this.animateProud(inst, t, react, hover, px, py);
        break;
      case "sleepy":
        this.animateSleepy(inst, t, react, hover, px, py);
        break;
      case "anxious":
        this.animateAnxious(inst, t, react, hover, px, py);
        break;
      case "welcome-back":
        this.animateWelcomeBack(inst, t, react, hover, px, py);
        break;
    }
  }

  /* --------------------------------------------------------------------------
     Complete Anime Visor, Brow, Eye Sensor & Catchlight System
     -------------------------------------------------------------------------- */
  private animateVisorAndEyes(
    inst: MascotRigInstance,
    t: number,
    blinkScaleY: number,
    react: number,
    hover: number,
    px: number,
    py: number
  ) {
    // State-specific full-range eye & head gaze targets
    let gazeX = 0; // ranges up to ±15px across the white visor!
    let gazeY = 0; // ranges up to ±4.5px vertically
    let headTurnX = 0; // visor 3D shift across face (±7px)
    let headTurnY = 0;
    let headTilt = 0;

    switch (inst.mascotId) {
      case "individual":
      case "focused": {
        // Reading smoothly across the left page -> across the right page -> page flip return!
        const readCycle = t * 1.35;
        gazeX = Math.sin(readCycle) * 13.5 + Math.sin(readCycle * 3) * 1.8;
        gazeY = 1.5 + Math.cos(readCycle * 2) * 2.2;
        headTurnX = Math.sin(readCycle - 0.25) * 5.2;
        headTurnY = 1.2 + Math.cos(readCycle) * 1.8;
        headTilt = Math.sin(readCycle) * 2.2;
        break;
      }
      case "pro": {
        // Confident anime hero gaze sweeping from laptop (-12) -> viewer (0) -> raised thumb (+13)
        const proWave = Math.sin(t * 1.15);
        gazeX = proWave * 13.0;
        gazeY = -Math.abs(proWave) * 2.2 + Math.cos(t * 2.3) * 1.5;
        headTurnX = Math.sin(t * 1.15 - 0.2) * 5.5;
        headTurnY = Math.cos(t * 1.15) * 2.0;
        headTilt = proWave * 2.4;
        break;
      }
      case "family": {
        // Warm family glances between each other and up toward the pulsing green heart
        gazeX = Math.sin(t * 1.25) * 10.5;
        gazeY = Math.cos(t * 1.25) * 3.2 - 1.0;
        headTurnX = Math.sin(t * 1.25 - 0.2) * 4.2;
        headTurnY = Math.cos(t * 1.25) * 1.8;
        headTilt = Math.sin(t * 1.25) * 2.0;
        break;
      }
      case "group": {
        // Lively collaborative glances around the study circle
        gazeX = Math.sin(t * 1.5) * 11.5;
        gazeY = Math.cos(t * 1.1) * 2.8;
        headTurnX = Math.sin(t * 1.5 - 0.2) * 4.5;
        headTurnY = Math.cos(t * 1.1) * 1.8;
        break;
      }
      case "proud": {
        // Heroic glance from viewer (-6) up toward the hoisted golden trophy (+14, -3.5)
        const proudSweep = 0.5 + 0.5 * Math.sin(t * 1.3);
        gazeX = -5 + proudSweep * 19; // -5px to +14px
        gazeY = 1.5 - proudSweep * 5.0; // +1.5px up to -3.5px
        headTurnX = -2 + proudSweep * 7.5;
        headTurnY = 1 - proudSweep * 3.5;
        headTilt = -proudSweep * 3.0;
        break;
      }
      case "anxious": {
        // During exam worry (first 2.4s of 6s cycle): eyes dart between EXAM paper (-13) and Clock (+14)
        // During calm mint aura phase (or on hover/tap): eyes settle into a serene, steady, confident gaze!
        const cycle = t % 6.0;
        const rawNervous = cycle < 2.4 ? Math.sin((cycle / 2.4) * Math.PI) : 0;
        const calmOverride = Math.min(1, hover * 0.85 + Math.abs(react) * 1.2);
        const nervous = rawNervous * (1 - calmOverride);

        const dart = Math.sin(t * 4.8) * 13.5 * nervous;
        const calmGazeX = Math.sin(t * 1.1) * 5.5 * (1 - nervous);
        gazeX = dart + calmGazeX;
        gazeY = nervous * 2.2 + Math.cos(t * 1.4) * 1.8 * (1 - nervous);
        headTurnX = gazeX * 0.38;
        headTurnY = Math.sin(t * 1.8) * 2.0;
        break;
      }
      case "welcome-back": {
        // Warm, enthusiastic greeting gaze tracking the returning learner
        gazeX = Math.sin(t * 1.4) * 12.0 + 2.0;
        gazeY = Math.cos(t * 2.1) * 2.6 - 1.0;
        headTurnX = Math.sin(t * 1.4 - 0.2) * 5.5;
        headTurnY = Math.cos(t * 2.1) * 2.2;
        headTilt = Math.sin(t * 1.4) * 2.8;
        break;
      }
      default: {
        gazeX = Math.sin(t * 1.3) * 10.0;
        gazeY = Math.cos(t * 1.1) * 2.4;
        headTurnX = Math.sin(t * 1.3 - 0.2) * 4.5;
        headTurnY = Math.cos(t * 1.1) * 1.8;
      }
    }

    // Blend procedural anime gaze with interactive pointer tracking when hovered
    const finalVisorX = headTurnX * (1 - hover * 0.5) + px * 7.5;
    const finalVisorY = headTurnY * (1 - hover * 0.5) + py * 5.0 - react * 3.5;
    const finalVisorRot = headTilt + px * 3.2;

    this.applyTransform(inst, "visor-panel", (el, i) => {
      const phaseShift = i * 0.4;
      const vx = finalVisorX + (i > 0 ? Math.sin(t * 1.4 + phaseShift) * 2.5 : 0);
      const vy = finalVisorY + (i > 0 ? Math.cos(t * 1.4 + phaseShift) * 1.5 : 0);
      el.style.transform = `translate3d(${vx.toFixed(2)}px, ${vy.toFixed(2)}px, 0) rotate(${finalVisorRot.toFixed(2)}deg)`;
    });

    // Expressive upper brow arch movement
    this.applyTransform(inst, "eye-brow", (el) => {
      const by = -Math.abs(gazeY) * 0.45 - react * 2.8 - hover * 1.5;
      const brot = gazeX * 0.15;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg)`;
    });

    // Full-range Black Optical Eye Sensor movement across the white visor
    const finalEyeX = Math.max(-16.5, Math.min(16.5, gazeX * (1 - hover * 0.55) + px * 14.0));
    const finalEyeY = Math.max(-4.5, Math.min(4.5, gazeY * (1 - hover * 0.55) + py * 4.2));
    const eyeScaleX = 1 + (1 - blinkScaleY) * 0.08 + react * 0.08;

    this.applyTransform(inst, "eye-sensor", (el, i) => {
      // For multi-character cards (Family & Group), give each member a slightly distinct gaze offset
      const memberOffset = i > 0 ? Math.sin(t * 1.5 + i * 1.3) * 5.5 : 0;
      const ex = Math.max(-16.5, Math.min(16.5, finalEyeX + memberOffset));
      el.style.transform = `translate3d(${ex.toFixed(2)}px, ${finalEyeY.toFixed(2)}px, 0) scale3d(${eyeScaleX.toFixed(3)}, ${blinkScaleY.toFixed(3)}, 1)`;
    });

    // Shimmering Anime Catchlights inside the optical sensor (counter-parallax + sparkle pulse)
    this.applyTransform(inst, "eye-glint", (el) => {
      const gx = -finalEyeX * 0.12 + Math.sin(t * 5.2) * 0.7;
      const gy = -finalEyeY * 0.12 + Math.cos(t * 4.6) * 0.7;
      const gs = 1 + 0.14 * Math.sin(t * 6.0) + react * 0.25 + hover * 0.1;
      el.style.transform = `translate3d(${gx.toFixed(2)}px, ${gy.toFixed(2)}px, 0) scale3d(${gs.toFixed(3)}, ${gs.toFixed(3)}, 1)`;
    });

    // Happy squinting eye arcs (^ ^) independent bounce & joyful squint
    this.applyTransform(inst, "happy-eye-l", (el) => {
      const hy = Math.sin(t * 2.8) * 2.2 - react * 3.5;
      const hrot = Math.sin(t * 2.8) * 6 - 4;
      const hsx = 1 + 0.08 * Math.sin(t * 5.6) + react * 0.15;
      const hsy = 1 - 0.06 * Math.sin(t * 5.6) + react * 0.12;
      el.style.transform = `translate3d(${(px * 4).toFixed(2)}px, ${hy.toFixed(2)}px, 0) rotate(${hrot.toFixed(2)}deg) scale3d(${hsx.toFixed(3)}, ${hsy.toFixed(3)}, 1)`;
    });

    this.applyTransform(inst, "happy-eye-r", (el) => {
      const hy = Math.sin(t * 2.8 - 0.15) * 2.2 - react * 3.5;
      const hrot = -Math.sin(t * 2.8) * 6 + 4;
      const hsx = 1 + 0.08 * Math.sin(t * 5.6) + react * 0.15;
      const hsy = 1 - 0.06 * Math.sin(t * 5.6) + react * 0.12;
      el.style.transform = `translate3d(${(px * 4).toFixed(2)}px, ${hy.toFixed(2)}px, 0) rotate(${hrot.toFixed(2)}deg) scale3d(${hsx.toFixed(3)}, ${hsy.toFixed(3)}, 1)`;
    });

    // Sleepy closed eye arc gentle breathing & dreamy flutter
    this.applyTransform(inst, "sleepy-eye", (el) => {
      const breath = Math.sin(t * 1.25);
      const sy = 1 + breath * 0.12;
      const ey = breath * 1.6;
      el.style.transform = `translate3d(0px, ${ey.toFixed(2)}px, 0) scale3d(1, ${sy.toFixed(3)}, 1)`;
    });
  }

  /* --------------------------------------------------------------------------
     1. INDIVIDUAL: Serene float, full reading eye scan, page flip & both arms
     -------------------------------------------------------------------------- */
  private animateIndividual(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    py: number
  ) {
    const floatY = Math.sin(t * 1.85) * 8.5 - react * 15 - hover * 3.5;
    const floatX = Math.cos(t * 0.925) * 3.2 + px * 6;
    const rot = Math.sin(t * 0.925) * 2.2 + px * 4;
    const stretch = 1 + Math.cos(t * 1.85) * 0.015 + react * 0.04;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${floatX.toFixed(2)}px, ${floatY.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg) scale3d(${(2 - stretch).toFixed(3)}, ${stretch.toFixed(3)}, 1)`;
    });

    // Open navy book tilts and breathes in 3D with phase lag
    this.applyTransform(inst, "book-prop", (el) => {
      const by = Math.sin(t * 1.85 - 0.55) * 4.5 + py * 3;
      const brot = Math.cos(t * 0.925 - 0.4) * 3.2 - react * 6;
      const bscale = 1 + Math.sin(t * 3.7) * 0.018 + react * 0.05;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg) scale3d(${bscale.toFixed(3)}, ${bscale.toFixed(3)}, 1)`;
    });

    // Smooth 3D page flip every read cycle
    const pageCycle = (t * 0.45) % 1; // 0..1
    const flipWindow = pageCycle > 0.68 ? (pageCycle - 0.68) / 0.32 : 0; // smooth page turn in final 32% of cycle
    const flipSin = Math.sin(flipWindow * Math.PI);

    this.applyTransform(inst, "flipping-page", (el) => {
      const scaleX = 1 - flipSin * 0.85;
      const skewY = -flipSin * 14 - react * 10;
      const liftY = -flipSin * 4;
      el.style.transform = `translate3d(0px, ${liftY.toFixed(2)}px, 0) skewY(${skewY.toFixed(2)}deg) scale3d(${scaleX.toFixed(3)}, 1, 1)`;
    });

    // Left Arm: steadies and tilts the left side of the book in a smooth arc
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.sin(t * 1.85) * 4.5 - 2;
      const ay = Math.cos(t * 1.85) * 5.5 - react * 8;
      const arot = Math.sin(t * 1.85) * 14 - react * 18;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Arm: traces across the page and lifts in a full arc to flip the page!
    this.applyTransform(inst, "arm-right", (el) => {
      const traceX = -Math.sin(t * 1.35) * 8.5 - flipSin * 14;
      const traceY = Math.cos(t * 2.7) * 6.0 - flipSin * 12 - react * 12;
      const arot = -Math.sin(t * 1.35) * 18 - flipSin * 22;
      el.style.transform = `translate3d(${traceX.toFixed(2)}px, ${traceY.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.animateParticles(inst, t, react, 7.5);
  }

  /* --------------------------------------------------------------------------
     2. PRO: Dignified hover, sweeping hero thumbs-up arm, laptop arm & tassel
     -------------------------------------------------------------------------- */
  private animatePro(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    py: number
  ) {
    const floatY = Math.sin(t * 1.75) * 7.8 - react * 16 - hover * 4;
    const floatX = Math.sin(t * 0.875) * 2.8 + px * 5.5;
    const rot = Math.cos(t * 1.75) * 1.8 + px * 3.5;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${floatX.toFixed(2)}px, ${floatY.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg)`;
    });

    // Mortarboard cap secondary tilt
    this.applyTransform(inst, "grad-cap", (el) => {
      const cy = Math.sin(t * 1.75 - 0.45) * 3.2 - react * 5;
      const crot = Math.sin(t * 1.75 - 0.6) * 3.0 + px * 3;
      el.style.transform = `translate3d(0px, ${cy.toFixed(2)}px, 0) rotate(${crot.toFixed(2)}deg)`;
    });

    // Lush multi-harmonic anime pendulum swing on gold tassel
    this.applyTransform(inst, "tassel", (el) => {
      const swing =
        Math.sin(t * 2.9 - 0.5) * 12.5 +
        Math.sin(t * 5.8) * 3.8 +
        react * 24 +
        px * 8;
      el.style.transform = `rotate(${swing.toFixed(2)}deg)`;
    });

    // Sleek navy laptop 3D hover & tilt
    this.applyTransform(inst, "laptop-prop", (el) => {
      const ly = Math.sin(t * 1.75 - 0.5) * 4.2 + py * 2.5;
      const lrot = Math.cos(t * 1.75 - 0.4) * 2.8 - react * 5;
      el.style.transform = `translate3d(0px, ${ly.toFixed(2)}px, 0) rotate(${lrot.toFixed(2)}deg)`;
    });

    // Left Arm: cradles and adjusts the laptop with smooth finger/wrist motion
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.cos(t * 2.4) * 5.5;
      const ay = Math.sin(t * 2.4) * 6.0 - react * 8;
      const arot = Math.sin(t * 2.4) * 15;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Arm (Thumbs-Up): Full sweeping anime hero salute arc!
    this.applyTransform(inst, "thumb-hand", (el) => {
      const tx = Math.cos(t * 2.1) * 5.0 + hover * 3;
      const ty = Math.sin(t * 2.1 - 0.3) * 9.5 - react * 16 - hover * 5;
      const trot = Math.sin(t * 2.1) * 16.5 - react * 24 - hover * 8;
      const ts = 1 + 0.04 * Math.sin(t * 2.1) + react * 0.1;
      el.style.transform = `translate3d(${tx.toFixed(2)}px, ${ty.toFixed(2)}px, 0) rotate(${trot.toFixed(2)}deg) scale3d(${ts.toFixed(3)}, ${ts.toFixed(3)}, 1)`;
    });

    this.animateParticles(inst, t, react, 6.5, true);
  }

  /* --------------------------------------------------------------------------
     3. FAMILY: Warm quartet bob, full embracing hug arms, hair & heart pulse
     -------------------------------------------------------------------------- */
  private animateFamily(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    // Father (top-left)
    this.applyTransform(inst, "dad", (el) => {
      const y = Math.sin(t * 1.85) * 6.2 - react * 12;
      const r = Math.sin(t * 0.925) * 2.6 + hover * 2.2 + px * 2.5;
      el.style.transform = `translate3d(${(px * 3.5).toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${r.toFixed(2)}deg)`;
    });

    // Mother (top-right, warm phase offset)
    this.applyTransform(inst, "mom", (el) => {
      const y = Math.sin(t * 1.85 - 0.35) * 6.2 - react * 12;
      const r = -Math.sin(t * 0.925 - 0.2) * 2.6 - hover * 2.2 + px * 2.5;
      el.style.transform = `translate3d(${(px * 3.5).toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${r.toFixed(2)}deg)`;
    });

    // Boy child (bottom-left)
    this.applyTransform(inst, "boy", (el) => {
      const y = Math.sin(t * 1.85 - 0.65) * 7.2 - react * 15;
      const r = Math.cos(t * 1.85) * 3.4 + px * 3.5;
      el.style.transform = `translate3d(${(px * 4.5).toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${r.toFixed(2)}deg)`;
    });

    // Girl child (bottom-right)
    this.applyTransform(inst, "girl", (el) => {
      const y = Math.sin(t * 1.85 - 0.85) * 7.2 - react * 15;
      const r = -Math.cos(t * 1.85 - 0.3) * 3.4 + px * 3.5;
      el.style.transform = `translate3d(${(px * 4.5).toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${r.toFixed(2)}deg)`;
    });

    // Parents' Hair Waves & Kids' Cap/Bow secondary breeze motion
    this.applyTransform(inst, "hair-wave", (el, i) => {
      const hrot = Math.sin(t * 2.4 + i) * 5.5;
      el.style.transform = `rotate(${hrot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "grad-cap", (el) => {
      const crot = Math.sin(t * 2.2) * 4.5 - react * 8;
      const cy = Math.cos(t * 2.2) * 2.5;
      el.style.transform = `translate3d(0px, ${cy.toFixed(2)}px, 0) rotate(${crot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "pink-bow", (el) => {
      const brot = Math.sin(t * 3.2) * 9.5 + react * 16;
      const bs = 1 + 0.06 * Math.cos(t * 3.2);
      el.style.transform = `rotate(${brot.toFixed(2)}deg) scale3d(${bs.toFixed(3)}, ${bs.toFixed(3)}, 1)`;
    });

    // Father's Left Embracing Arm & Mother's Right Embracing Arm (complete warm hugging motion!)
    const hugWave = Math.sin(t * 1.85 - 0.4);
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = hugWave * 6.5 + hover * 4 + react * 8;
      const ay = Math.cos(t * 1.85) * 5.5 - react * 10;
      const arot = -hugWave * 14 - hover * 6 - react * 14;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "arm-right", (el) => {
      const ax = -hugWave * 6.5 - hover * 4 - react * 8;
      const ay = Math.cos(t * 1.85 - 0.25) * 5.5 - react * 10;
      const arot = hugWave * 14 + hover * 6 + react * 14;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Realistic double-beat heart pulse (lub-dub)
    this.applyTransform(inst, "family-heart", (el) => {
      const beatPhase = (t * 1.3) % 1;
      const lub = Math.exp(-Math.pow((beatPhase - 0.18) / 0.07, 2)) * 0.18;
      const dub = Math.exp(-Math.pow((beatPhase - 0.36) / 0.09, 2)) * 0.12;
      const scale = 1 + lub + dub + react * 0.3 + hover * 0.09;
      const hy = Math.sin(t * 1.85) * 5.5 - react * 14;
      const hrot = Math.sin(t * 0.925) * 4;
      el.style.transform = `translate3d(0px, ${hy.toFixed(2)}px, 0) rotate(${hrot.toFixed(2)}deg) scale3d(${scale.toFixed(3)}, ${scale.toFixed(3)}, 1)`;
    });

    this.animateParticles(inst, t, react, 5.5);
  }

  /* --------------------------------------------------------------------------
     4. GROUP: 4 Staggered Collaborators + Sweeping Cheer Arm + Gesturing Hands
     -------------------------------------------------------------------------- */
  private animateGroup(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    const members = ["member-1", "member-2", "member-3", "member-4"];
    members.forEach((key, idx) => {
      this.applyTransform(inst, key, (el) => {
        const phase = idx * 0.85;
        const y = Math.sin(t * 2.0 - phase) * 6.8 - react * (12 + idx * 2) - hover * 2.5;
        const x = Math.cos(t * 1.0 - phase) * 2.4 + px * (3 + idx);
        const r = Math.sin(t * 1.0 - phase) * 2.8;
        el.style.transform = `translate3d(${x.toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${r.toFixed(2)}deg)`;
      });
    });

    // Top member's cheering arm waves across a wide 32-degree arc
    this.applyTransform(inst, "cheer-hand", (el) => {
      const rot = Math.sin(t * 3.4) * 18 - react * 26 - hover * 8;
      const y = Math.cos(t * 3.4) * 6.5 - react * 10;
      const x = Math.sin(t * 3.4) * 4.5;
      el.style.transform = `translate3d(${x.toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg)`;
    });

    // Collaborators' left and right hands actively gesturing over books & laptop
    this.applyTransform(inst, "arm-left", (el, i) => {
      const ax = Math.cos(t * 2.6 + i) * 6.0;
      const ay = Math.sin(t * 2.6 + i) * 6.5 - react * 9;
      const arot = Math.sin(t * 2.6 + i) * 16;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "arm-right", (el, i) => {
      const ax = -Math.sin(t * 2.6 + i) * 6.5;
      const ay = Math.cos(t * 2.6 + i) * 6.5 - react * 9;
      const arot = -Math.cos(t * 2.6 + i) * 16;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "book-prop", (el, i) => {
      const by = Math.sin(t * 2.0 - 0.5 - i) * 3.5;
      const brot = Math.cos(t * 2.0 - i) * 2.5;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg)`;
    });

    this.animateParticles(inst, t, react, 7.0);
  }

  /* --------------------------------------------------------------------------
     5. FOCUSED: Lo-Fi Anime Study Rhythm, Full Reading Eye, Page Flip & Arms
     -------------------------------------------------------------------------- */
  private animateFocused(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    py: number
  ) {
    // Serene study breathing & gentle head nod to the music in headphones
    const breatheY = Math.sin(t * 1.7) * 5.8 - react * 12 - hover * 2.5;
    const tilt = 1.0 + Math.sin(t * 1.7 - 0.4) * 2.2 + px * 3.2;
    const breathScaleX = 1 + Math.sin(t * 1.7) * 0.016;
    const breathScaleY = 1 - Math.sin(t * 1.7) * 0.014;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${(px * 4.5).toFixed(2)}px, ${breatheY.toFixed(2)}px, 0) rotate(${tilt.toFixed(2)}deg) scale3d(${breathScaleX.toFixed(3)}, ${breathScaleY.toFixed(3)}, 1)`;
    });

    // Headphone ear cups subtle rhythm pulse
    this.applyTransform(inst, "headphone-cup", (el) => {
      const hs = 1 + 0.025 * Math.sin(t * 3.4);
      el.style.transform = `scale3d(${hs.toFixed(3)}, ${hs.toFixed(3)}, 1)`;
    });

    // Open book follow-through
    this.applyTransform(inst, "focused-book", (el) => {
      const by = Math.sin(t * 1.7 - 0.5) * 3.8 + py * 2.5;
      const brot = Math.cos(t * 1.7 - 0.5) * 2.4 - react * 5;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg)`;
    });

    // Smooth 3D page flip synchronized with reading eye scan
    const pageCycle = (t * 0.42) % 1;
    const flipWindow = pageCycle > 0.66 ? (pageCycle - 0.66) / 0.34 : 0;
    const flipSin = Math.sin(flipWindow * Math.PI);

    this.applyTransform(inst, "flipping-page", (el) => {
      const scaleX = 1 - flipSin * 0.88;
      const skewY = -flipSin * 15 - react * 10;
      const liftY = -flipSin * 4.5;
      el.style.transform = `translate3d(0px, ${liftY.toFixed(2)}px, 0) skewY(${skewY.toFixed(2)}deg) scale3d(${scaleX.toFixed(3)}, 1, 1)`;
    });

    // Left Arm: steadies the left book cover with gentle arc
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.sin(t * 1.7) * 4.2;
      const ay = Math.cos(t * 1.7) * 5.2 - react * 8;
      const arot = Math.sin(t * 1.7) * 14;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Arm: traces across the open page and lifts in a smooth arc to turn the page!
    this.applyTransform(inst, "arm-right", (el) => {
      const traceX = -Math.sin(t * 1.35) * 9.0 - flipSin * 15;
      const traceY = Math.cos(t * 2.7) * 6.5 - flipSin * 13 - react * 12;
      const arot = -Math.sin(t * 1.35) * 19 - flipSin * 24;
      el.style.transform = `translate3d(${traceX.toFixed(2)}px, ${traceY.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Desk lamp warm light beam breathing
    this.applyTransform(inst, "lamp-beam", (el) => {
      const op = 0.48 + 0.26 * Math.sin(t * 2.1) + hover * 0.18 + react * 0.25;
      const s = 1 + 0.05 * Math.sin(t * 2.1);
      el.style.opacity = Math.min(0.95, op).toFixed(3);
      el.style.transform = `scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
    });

    // Continuous 60fps sweeping wall-clock minute hand
    this.applyTransform(inst, "wall-clock-hand", (el) => {
      const deg = (t * 28) % 360;
      el.style.transform = `rotate(${deg.toFixed(2)}deg)`;
    });

    // Inverse desk shadow
    this.applyTransform(inst, "ground-shadow", (el) => {
      const s = 1 - breatheY / 55;
      el.style.transform = `scale3d(${s.toFixed(3)}, 1, 1)`;
    });

    this.animateParticles(inst, t, react, 5.8);
  }

  /* --------------------------------------------------------------------------
     6. HAPPY: Joyful Anime Victory Leap, Both Arms Cheering, Checkmark & Card
     -------------------------------------------------------------------------- */
  private animateHappy(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    py: number
  ) {
    // Upbeat anime celebration bounce with squash & stretch
    const bounce = Math.sin(t * 2.65);
    const y = bounce * 9.5 - react * 20 - hover * 4.5;
    const x = Math.cos(t * 1.325) * 3.5 + px * 5.5;
    const rot = Math.sin(t * 1.325) * 4.0 + px * 4.5 + react * 7;
    const sx = 1 - bounce * 0.022;
    const sy = 1 + bounce * 0.026 + react * 0.06;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${x.toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg) scale3d(${sx.toFixed(3)}, ${sy.toFixed(3)}, 1)`;
    });

    // Left Arm: energetic victory pump & swing
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.cos(t * 2.65) * 6.5;
      const ay = -Math.sin(t * 2.65 - 0.3) * 9.5 - react * 14;
      const arot = Math.sin(t * 2.65 - 0.3) * 24 + react * 26;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Raised Arm: full-arc anime celebration wave!
    this.applyTransform(inst, "wave-hand", (el) => {
      const wrot = Math.sin(t * 4.2) * 22 - react * 28 - hover * 10;
      const wy = Math.cos(t * 2.65) * 7.5 - react * 12;
      const wx = Math.sin(t * 4.2) * 4.5;
      el.style.transform = `translate3d(${wx.toFixed(2)}px, ${wy.toFixed(2)}px, 0) rotate(${wrot.toFixed(2)}deg)`;
    });

    // 3D Green Checkmark Badge bobbing & popping
    this.applyTransform(inst, "check-badge", (el) => {
      const cy = Math.sin(t * 2.65 - 0.7) * 7.0 - react * 14;
      const cs = 1 + 0.07 * Math.sin(t * 2.65) + react * 0.2 + hover * 0.07;
      const crot = Math.cos(t * 1.325) * 5.5 + react * 12;
      el.style.transform = `translate3d(${(px * -3.5).toFixed(2)}px, ${cy.toFixed(2)}px, 0) rotate(${crot.toFixed(2)}deg) scale3d(${cs.toFixed(3)}, ${cs.toFixed(3)}, 1)`;
    });

    // Foreground Quiz Answer UI Card 3D counter-float
    this.applyTransform(inst, "quiz-card", (el) => {
      const qy = Math.cos(t * 2.1) * 4.8 + py * 3.5;
      const qrot = Math.sin(t * 2.1) * 2.2 + px * 2.5;
      el.style.transform = `translate3d(${(px * 3.5).toFixed(2)}px, ${qy.toFixed(2)}px, 0) rotate(${qrot.toFixed(2)}deg)`;
    });

    this.animateParticles(inst, t, react, 8.5, true);
  }

  /* --------------------------------------------------------------------------
     7. PROUD: Heroic Lift, Billowing Navy Cape, Grand Trophy Hoist & Star Gleam
     -------------------------------------------------------------------------- */
  private animateProud(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    const liftY = Math.sin(t * 1.9) * 7.5 - react * 16 - hover * 4.5;
    const rot = Math.cos(t * 0.95) * 2.2 + px * 3.5;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${(px * 4.5).toFixed(2)}px, ${liftY.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg)`;
    });

    // Billowing dark-navy hero cape in the wind (lush multi-frequency wave)
    this.applyTransform(inst, "cape", (el) => {
      const capeRot = Math.sin(t * 3.2) * 7.5 + Math.cos(t * 4.8) * 3.2 + react * 14;
      const capeSkew = Math.cos(t * 3.2) * 6.5;
      const capeScaleX = 1 + Math.sin(t * 3.2 - 0.5) * 0.065 + react * 0.1;
      el.style.transform = `rotate(${capeRot.toFixed(2)}deg) skewX(${capeSkew.toFixed(2)}deg) scale3d(${capeScaleX.toFixed(3)}, 1, 1)`;
    });

    // Left Hero Arm poised proudly on chest/hip
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.cos(t * 1.9) * 4.5;
      const ay = Math.sin(t * 1.9 - 0.3) * 5.5 - react * 8;
      const arot = Math.sin(t * 1.9) * 14 - react * 16;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Arm & Golden Trophy hoisted high into the sky in a grand sweeping arc!
    this.applyTransform(inst, "trophy", (el) => {
      const ty = Math.sin(t * 1.9 - 0.45) * 9.5 - react * 18 - hover * 6;
      const tx = Math.cos(t * 1.9) * 4.0 + hover * 3;
      const trot = Math.sin(t * 1.9) * 11.5 - react * 16 - hover * 5;
      const ts = 1 + 0.04 * Math.sin(t * 3.8) + react * 0.14;
      el.style.transform = `translate3d(${tx.toFixed(2)}px, ${ty.toFixed(2)}px, 0) rotate(${trot.toFixed(2)}deg) scale3d(${ts.toFixed(3)}, ${ts.toFixed(3)}, 1)`;
    });

    // Rotating anime star-gleam on the trophy cup rim
    this.applyTransform(inst, "trophy-gleam", (el) => {
      const grot = (t * 95) % 360;
      const gs = 0.75 + 0.45 * Math.abs(Math.sin(t * 3.5)) + react * 0.4;
      el.style.transform = `rotate(${grot.toFixed(1)}deg) scale3d(${gs.toFixed(3)}, ${gs.toFixed(3)}, 1)`;
    });

    // Rising golden anime action arrows
    this.applyTransform(inst, "rising-arrow", (el, i) => {
      const ay = Math.sin(t * 2.4 + i * 1.2) * 9.5 - react * 14;
      const as = 1 + 0.06 * Math.cos(t * 2.4 + i);
      el.style.transform = `translate3d(0px, ${ay.toFixed(2)}px, 0) scale3d(${as.toFixed(3)}, ${as.toFixed(3)}, 1)`;
    });

    this.animateParticles(inst, t, react, 7.5, true);
  }

  /* --------------------------------------------------------------------------
     8. SLEEPY: Serene Slumber, Curling Hands, Breathing Blanket & Rising Zs
     -------------------------------------------------------------------------- */
  private animateSleepy(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    // Deep, serene 60fps sleeping breath
    const breath = Math.sin(t * 1.25);
    const y = breath * 4.5 + react * 5;
    const rot = breath * 2.0 + px * 2.0;
    const sx = 1 + breath * 0.026 + react * 0.03;
    const sy = 1 - breath * 0.022;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${(px * 3).toFixed(2)}px, ${y.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg) scale3d(${sx.toFixed(3)}, ${sy.toFixed(3)}, 1)`;
    });

    // Plush pillow gently compressing and cradling Hesi's head
    this.applyTransform(inst, "pillow", (el) => {
      const py = breath * 2.4;
      const psx = 1 - breath * 0.02;
      const psy = 1 + breath * 0.02;
      el.style.transform = `translate3d(0px, ${py.toFixed(2)}px, 0) scale3d(${psx.toFixed(3)}, ${psy.toFixed(3)}, 1)`;
    });

    // Cozy navy blanket expanding and settling with Hesi's chest breath
    this.applyTransform(inst, "blanket", (el) => {
      const by = -breath * 2.8;
      const bs = 1 + breath * 0.028;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) scale3d(${bs.toFixed(3)}, ${bs.toFixed(3)}, 1)`;
    });

    // Both tucked hands curl and nestle gently near Hesi's cheek
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.sin(t * 1.25 - 0.25) * 4.2;
      const ay = Math.cos(t * 1.25 - 0.25) * 4.8 - react * 7;
      const arot = Math.sin(t * 1.25) * 12;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "arm-right", (el) => {
      const ax = -Math.cos(t * 1.25 - 0.45) * 4.8;
      const ay = Math.sin(t * 1.25 - 0.45) * 5.2 - react * 8;
      const arot = -Math.cos(t * 1.25) * 14;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Crescent moon badge gentle cradle rock
    this.applyTransform(inst, "moon-badge", (el) => {
      const my = Math.sin(t * 1.45) * 5.2;
      const mrot = Math.cos(t * 1.45) * 7.5 + hover * 8;
      el.style.transform = `translate3d(0px, ${my.toFixed(2)}px, 0) rotate(${mrot.toFixed(2)}deg)`;
    });

    // Continuous 60fps rising & spiraling 'Z' sleep particles
    this.applyTransform(inst, "z-particle", (el, i) => {
      const period = 3.6;
      const progress = ((t * 0.72 + i * (period / 2)) % period) / period;
      const zx = Math.sin(progress * Math.PI * 2 + i) * 8.5 + progress * 16;
      const zy = -progress * 36;
      const zScale = 0.72 + Math.sin(progress * Math.PI) * 0.46 + react * 0.16;
      const zOp = Math.sin(progress * Math.PI);
      const zRot = Math.cos(progress * Math.PI * 2) * 10;
      el.style.transform = `translate3d(${zx.toFixed(2)}px, ${zy.toFixed(2)}px, 0) rotate(${zRot.toFixed(2)}deg) scale3d(${zScale.toFixed(3)}, ${zScale.toFixed(3)}, 1)`;
      el.style.opacity = Math.max(0.08, zOp).toFixed(3);
    });

    this.animateParticles(inst, t, react, 4.5);
  }

  /* --------------------------------------------------------------------------
     9. ANXIOUS: Expressive Worry-to-Serenity Arc (Arms, Brows, Clock & Calm Cue)
     -------------------------------------------------------------------------- */
  private animateAnxious(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    // 6-second story cycle:
    // 0..2.4s: gentle anime exam worry (hands lift toward cheeks, brows knit, clock rings)
    // 2.4..6.0s: serene mint-emerald calming breath wave (hands lower smoothly, brows relax, steady breath)
    const cycle = t % 6.0;
    const rawNervous = cycle < 2.4 ? Math.sin((cycle / 2.4) * Math.PI) : 0;
    const calmOverride = Math.min(1, hover * 0.85 + Math.abs(react) * 1.2);
    const nervousAmount = rawNervous * (1 - calmOverride);
    const calmAmount = 1 - nervousAmount;

    const tremorX = Math.sin(t * 24) * 1.8 * nervousAmount + px * 3.5;
    const breathY = Math.sin(t * 1.75) * 5.8 - react * 12;
    const rot = Math.cos(t * 20) * 1.2 * nervousAmount + Math.sin(t * 1.75) * 1.8;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${tremorX.toFixed(2)}px, ${breathY.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg)`;
    });

    // Left & Right Articulated Hands:
    // Rise inward toward Hesi's cheeks during exam worry, then smoothly open & lower during the calming breath!
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = nervousAmount * 8.5 + Math.sin(t * 1.75) * 4.5 * calmAmount;
      const ay = -nervousAmount * 14.5 + Math.cos(t * 1.75) * 5.5 * calmAmount - react * 10;
      const arot = nervousAmount * 22 + Math.sin(t * 1.75) * 12 * calmAmount;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "arm-right", (el) => {
      const ax = -nervousAmount * 8.5 - Math.sin(t * 1.75) * 4.5 * calmAmount;
      const ay = -nervousAmount * 14.5 + Math.cos(t * 1.75 - 0.2) * 5.5 * calmAmount - react * 10;
      const arot = -nervousAmount * 22 - Math.sin(t * 1.75) * 12 * calmAmount;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Articulated Worried Brows: knit during worry, lift into a serene arch during calm phase
    this.applyTransform(inst, "worried-brow-l", (el) => {
      const by = -calmAmount * 2.8;
      const brot = nervousAmount * 8 - calmAmount * 6;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "worried-brow-r", (el) => {
      const by = -calmAmount * 2.8;
      const brot = -nervousAmount * 8 + calmAmount * 6;
      el.style.transform = `translate3d(0px, ${by.toFixed(2)}px, 0) rotate(${brot.toFixed(2)}deg)`;
    });

    // Sweat droplets gently fade back during calm phase
    this.applyTransform(inst, "sweat-drop", (el, i) => {
      const dy = ((t * 1.8 + i * 0.5) % 1) * 6 * nervousAmount;
      const op = 0.25 + nervousAmount * 0.75;
      el.style.transform = `translate3d(0px, ${dy.toFixed(2)}px, 0)`;
      el.style.opacity = op.toFixed(3);
    });

    // Calming mint reassurance aura expands smoothly during the calm phase or on hover/tap
    this.applyTransform(inst, "calm-aura", (el) => {
      const auraScale = 0.92 + calmAmount * 0.14 + Math.sin(t * 1.9) * 0.035 + react * 0.1;
      const auraOp = 0.35 + calmAmount * 0.58;
      el.style.transform = `scale3d(${auraScale.toFixed(3)}, ${auraScale.toFixed(3)}, 1)`;
      el.style.opacity = Math.min(1, auraOp).toFixed(3);
    });

    // Twin-bell alarm clock vibration & sweeping hand
    this.applyTransform(inst, "alarm-clock", (el) => {
      const cy = Math.cos(t * 2.1) * 4.2;
      const crot = Math.sin(t * 28) * 3.2 * nervousAmount + Math.sin(t * 2.1) * 2.5;
      el.style.transform = `translate3d(0px, ${cy.toFixed(2)}px, 0) rotate(${crot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "clock-minute-hand", (el) => {
      const deg = (t * 48) % 360;
      el.style.transform = `rotate(${deg.toFixed(2)}deg)`;
    });

    // EXAM sheet & yellow pencil gentle float
    this.applyTransform(inst, "exam-sheet", (el) => {
      const ey = Math.sin(t * 1.9 - 0.4) * 3.8;
      const erot = Math.cos(t * 1.9) * 2.2;
      el.style.transform = `translate3d(0px, ${ey.toFixed(2)}px, 0) rotate(${erot.toFixed(2)}deg)`;
    });

    this.applyTransform(inst, "pencil", (el) => {
      const py = Math.sin(t * 2.3 - 0.9) * 5.2 - react * 8;
      const prot = Math.sin(t * 2.3) * 5.5;
      el.style.transform = `translate3d(0px, ${py.toFixed(2)}px, 0) rotate(${prot.toFixed(2)}deg)`;
    });

    this.animateParticles(inst, t, react, 5.2);
  }

  /* --------------------------------------------------------------------------
     10. WELCOME BACK: Full Sweeping Anime Greeting Wave, Left Arm & Doorway
     -------------------------------------------------------------------------- */
  private animateWelcomeBack(
    inst: MascotRigInstance,
    t: number,
    react: number,
    hover: number,
    px: number,
    _py: number
  ) {
    const floatY = Math.sin(t * 1.95) * 7.2 - react * 15 - hover * 3.5;
    const floatX = Math.cos(t * 0.975) * 3.0 + px * 5.0;
    const rot = Math.sin(t * 0.975) * 2.6 + px * 3.5;

    this.applyTransform(inst, "main-float", (el) => {
      el.style.transform = `translate3d(${floatX.toFixed(2)}px, ${floatY.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg)`;
    });

    // Left Arm: warm inviting open-arm gesture
    this.applyTransform(inst, "arm-left", (el) => {
      const ax = Math.cos(t * 1.95) * 5.5 - hover * 3;
      const ay = Math.sin(t * 1.95 - 0.4) * 6.5 - react * 10;
      const arot = Math.sin(t * 1.95) * 16 + hover * 8 + react * 16;
      el.style.transform = `translate3d(${ax.toFixed(2)}px, ${ay.toFixed(2)}px, 0) rotate(${arot.toFixed(2)}deg)`;
    });

    // Right Arm: Full, wide 36-degree sweeping anime greeting wave!
    this.applyTransform(inst, "wave-hand", (el) => {
      const waveRot =
        Math.sin(t * 3.6) * 20 +
        Math.sin(t * 7.2) * 4.5 -
        react * 26 -
        hover * 8;
      const wy = Math.cos(t * 3.6) * 6.5 - react * 10;
      const wx = Math.sin(t * 3.6) * 4.5;
      el.style.transform = `translate3d(${wx.toFixed(2)}px, ${wy.toFixed(2)}px, 0) rotate(${waveRot.toFixed(2)}deg)`;
    });

    // Sunlit doorway warm glow breathing
    this.applyTransform(inst, "door-glow", (el) => {
      const op = 0.78 + 0.22 * Math.sin(t * 2.2) + hover * 0.15;
      el.style.opacity = Math.min(1, op).toFixed(3);
    });

    // Potted plant leaves swaying in the doorway breeze
    this.applyTransform(inst, "plant-leaves", (el) => {
      const sway = Math.sin(t * 2.3) * 6.5 + Math.cos(t * 4.6) * 2.0 + hover * 4;
      el.style.transform = `rotate(${sway.toFixed(2)}deg)`;
    });

    // Pulsing green heart notification bubble
    this.applyTransform(inst, "heart-bubble", (el) => {
      const hy = Math.sin(t * 2.4 - 0.4) * 6.2 - react * 14;
      const hs = 1 + 0.08 * Math.sin(t * 3.6) + react * 0.22 + hover * 0.09;
      const hrot = Math.cos(t * 1.8) * 4.2;
      el.style.transform = `translate3d(0px, ${hy.toFixed(2)}px, 0) rotate(${hrot.toFixed(2)}deg) scale3d(${hs.toFixed(3)}, ${hs.toFixed(3)}, 1)`;
    });

    this.animateParticles(inst, t, react, 6.2);
  }

  /* --------------------------------------------------------------------------
     Shared Individual Particle Animator (each particle moves on its own phase!)
     -------------------------------------------------------------------------- */
  private animateParticles(
    inst: MascotRigInstance,
    t: number,
    react: number,
    amplitude = 6.5,
    twinkleScale = false
  ) {
    this.applyTransform(inst, "particle", (el, i) => {
      const phase = i * 1.15;
      const freq = 1.85 + (i % 3) * 0.32;
      const dx = Math.cos(t * (freq * 0.7) + phase) * (amplitude * 0.52);
      const dy = Math.sin(t * freq + phase) * amplitude - react * (9 + i * 1.5);
      const rot = Math.sin(t * (freq * 0.8) + phase) * (twinkleScale ? 14 : 8) + react * 18;
      const s = twinkleScale
        ? 1 + 0.16 * Math.sin(t * (freq * 1.3) + phase) + react * 0.22
        : 1 + 0.07 * Math.sin(t * freq + phase) + react * 0.14;
      el.style.transform = `translate3d(${dx.toFixed(2)}px, ${dy.toFixed(2)}px, 0) rotate(${rot.toFixed(2)}deg) scale3d(${s.toFixed(3)}, ${s.toFixed(3)}, 1)`;
    });
  }
}

export const animationEngine60fps = new AnimationEngine60FPS();
