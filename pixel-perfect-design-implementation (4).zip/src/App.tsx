import { useEffect, useState } from "react";
import {
  ALL_MASCOTS,
  EMOTIONAL_MASCOTS,
  SUBSCRIPTION_MASCOTS,
  type MascotId,
  type MascotItem,
} from "./data/mascots";
import { DEFAULT_LAYERS, MascotBadgeIcon, type LayerVisibility } from "./components/HesiCoreParts";
import HesiHeaderLockup, { HesiBrandMark } from "./components/HesiHeaderLockup";
import LivePlaygroundModal from "./components/LivePlaygroundModal";
import MascotCard, { type LanguageMode } from "./components/MascotCard";
import MascotRenderer from "./components/MascotRenderer";
import { animationEngine60fps } from "./utils/animationEngine60fps";

export default function App() {
  const [lang, setLang] = useState<LanguageMode>("bilingual");
  const [reducedMotion, setReducedMotion] = useState(false);
  const [speed, setSpeed] = useState(1);
  const [inspectedMascot, setInspectedMascot] = useState<MascotItem | null>(null);

  // Interactive Simulator State
  const [simMascotId, setSimMascotId] = useState<MascotId>("focused");
  const [simLayers, setSimLayers] = useState<Required<LayerVisibility>>(DEFAULT_LAYERS);
  const [simReactionCount, setSimReactionCount] = useState(0);

  // Sync system prefers-reduced-motion on mount
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReducedMotion(mq.matches);
    animationEngine60fps.setReducedMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => {
      setReducedMotion(e.matches);
      animationEngine60fps.setReducedMotion(e.matches);
    };
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const handleToggleReducedMotion = () => {
    setReducedMotion((prev) => {
      const next = !prev;
      animationEngine60fps.setReducedMotion(next);
      return next;
    });
  };

  const handleChangeSpeed = (nextSpeed: number) => {
    setSpeed(nextSpeed);
    animationEngine60fps.setSpeedMultiplier(nextSpeed);
  };

  const simItem =
    ALL_MASCOTS.find((m) => m.id === simMascotId) || EMOTIONAL_MASCOTS[0];

  const triggerSimReaction = () => {
    setSimReactionCount((c) => c + 1);
  };

  const toggleSimLayer = (key: keyof LayerVisibility) => {
    setSimLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  return (
    <div
      id="top"
      className={`min-h-svh bg-[#F7FCF9] text-[#0F1D3A] ${
        reducedMotion ? "reduced-motion" : ""
      }`}
    >
      {/* Sticky Header with Authentic Reference Image 2 Lockup + 60 FPS Telemetry */}
      <HesiHeaderLockup
        lang={lang}
        onChangeLang={setLang}
        reducedMotion={reducedMotion}
        onToggleReducedMotion={handleToggleReducedMotion}
        speed={speed}
        onChangeSpeed={handleChangeSpeed}
      />

      <main>
        {/* =================================================================
            HERO SECTION — Overview & Quick Interactive 60fps Switcher
            ================================================================= */}
        <section className="relative overflow-hidden border-b border-[#DCEEE3] bg-gradient-to-b from-white via-[#F6FCF8] to-[#ECF9F2] py-12 sm:py-16">
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid items-center gap-10 lg:grid-cols-12">
              {/* Hero Copy */}
              <div className="lg:col-span-7">
                <div className="inline-flex flex-wrap items-center gap-2 rounded-full border border-[#BFE8D1] bg-white px-3.5 py-1.5 text-xs font-semibold text-[#0D7A3E] shadow-2xs">
                  <span className="h-2 w-2 rounded-full bg-[#22C55E]" />
                  <span>60 FPS Multi-Joint Character Animation & Spring Physics</span>
                  <span className="text-[#94A3B8]">•</span>
                  <span className="font-arabic" dir="rtl">
                    ٤ باقات اشتراك + ٦ تعبيرات شعورية
                  </span>
                </div>

                <h1 className="mt-5 font-display text-3xl font-extrabold tracking-tight text-[#0F1D3A] sm:text-5xl sm:leading-[1.12]">
                  Meet{" "}
                  <span className="bg-gradient-to-r from-[#16A34A] to-[#0D8A3E] bg-clip-text text-transparent">
                    Hesi (هيسي)
                  </span>{" "}
                  — animated at a silky-smooth 60 frames per second.
                </h1>

                <p className="mt-4 max-w-2xl text-base leading-relaxed text-[#334E68]">
                  Faithfully recreated from the official Hesi visual references with a real-time{" "}
                  <strong>60fps procedural animation & spring physics engine</strong>: featuring
                  secondary follow-through on books, laptops, capes, and trophies, natural optical
                  eye blinking and reading saccades, pendulum tassel motion, and independent
                  particle orbits across all <strong>10 Hesi mascots</strong>.
                </p>

                {/* Quick Jump Pills */}
                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <a
                    href="#subscription-mascots"
                    className="inline-flex items-center gap-2 rounded-full bg-[#16A34A] px-5 py-2.5 text-sm font-bold text-white shadow-md shadow-[#16A34A]/20 transition-all hover:-translate-y-0.5 hover:bg-[#15803D] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
                  >
                    <span>Explore 4 Subscription Mascots</span>
                    <span aria-hidden="true">↓</span>
                  </a>
                  <a
                    href="#emotional-mascots"
                    className="inline-flex items-center gap-2 rounded-full border border-[#BFE8D1] bg-white px-5 py-2.5 text-sm font-bold text-[#0F1D3A] shadow-2xs transition-all hover:-translate-y-0.5 hover:border-[#16A34A] hover:text-[#16A34A] focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none"
                  >
                    <span>Explore 6 Emotional States</span>
                    <span className="font-arabic text-xs font-bold text-[#16A34A]" dir="rtl">
                      (تعبيرات هيسي)
                    </span>
                  </a>
                </div>

                {/* Key Highlights */}
                <dl className="mt-8 grid grid-cols-2 gap-4 border-t border-[#D8EFE2] pt-6 sm:grid-cols-4">
                  <div>
                    <dt className="text-xs font-semibold text-[#475569]">Frame Rate</dt>
                    <dd className="mt-0.5 font-display text-lg font-extrabold text-[#16A34A]">
                      60 FPS rAF Loop
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-semibold text-[#475569]">Subscription Plans</dt>
                    <dd className="mt-0.5 font-display text-lg font-extrabold text-[#0F1D3A]">
                      4 Tiers
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-semibold text-[#475569]">Emotional States</dt>
                    <dd className="mt-0.5 font-display text-lg font-extrabold text-[#0F1D3A]">
                      6 Expressions
                    </dd>
                  </div>
                  <div>
                    <dt className="text-xs font-semibold text-[#475569]">Secondary Motion</dt>
                    <dd className="mt-0.5 font-display text-lg font-extrabold text-[#0F1D3A]">
                      Spring + Overlap
                    </dd>
                  </div>
                </dl>
              </div>

              {/* Hero Right: Live Interactive 60fps Mascot Stage Preview */}
              <div className="lg:col-span-5">
                <div className="rounded-[30px] border border-[#BFE8D1] bg-white p-5 shadow-[0_20px_50px_-15px_rgba(22,163,74,0.16)]">
                  <div className="flex items-center justify-between border-b border-[#E8F5EE] pb-3">
                    <div className="flex items-center gap-2">
                      <span className="h-2.5 w-2.5 rounded-full bg-[#22C55E]" />
                      <span className="text-xs font-bold uppercase tracking-wider text-[#334E68]">
                        Live 60 FPS Rig Stage (Move Pointer or Click)
                      </span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setInspectedMascot(simItem)}
                      className="text-xs font-bold text-[#16A34A] hover:underline"
                    >
                      Inspect Rig →
                    </button>
                  </div>

                  <div
                    role="button"
                    tabIndex={0}
                    onClick={triggerSimReaction}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        triggerSimReaction();
                      }
                    }}
                    aria-label="Move pointer to track gaze or click to trigger 60fps spring reaction"
                    className="mx-auto my-2 flex aspect-[10/8.5] w-full max-w-[310px] cursor-pointer items-center justify-center rounded-2xl outline-none focus-visible:ring-2 focus-visible:ring-[#16A34A]"
                  >
                    <MascotRenderer
                      id={simItem.id}
                      reactionTrigger={simReactionCount}
                    />
                  </div>

                  {/* Pill Badge matching Reference Image 2 */}
                  <div className="mx-auto flex max-w-[290px] items-center justify-between gap-3 rounded-full border border-[#BDE8D0] bg-[#EBF9F1] px-3.5 py-2">
                    <MascotBadgeIcon type={simItem.iconType} accentColor={simItem.accentColor} />
                    <div className="text-center leading-tight">
                      <div className="flex items-center justify-center gap-1.5">
                        <span className="font-display text-sm font-bold text-[#0F1D3A]">
                          {simItem.nameEn}
                        </span>
                        <span className="text-xs text-[#94A3B8]">•</span>
                        <span className="font-arabic text-sm font-bold text-[#0F1D3A]" dir="rtl">
                          {simItem.nameAr}
                        </span>
                      </div>
                      <p className="text-[11px] font-medium text-[#334E68]">
                        {simItem.subtitleEn} /{" "}
                        <span className="font-arabic" dir="rtl">
                          {simItem.subtitleAr}
                        </span>
                      </p>
                    </div>
                    <div className="w-3" aria-hidden="true" />
                  </div>

                  {/* Mini 10-state selector strip */}
                  <div className="mt-4 flex flex-wrap justify-center gap-1.5">
                    {ALL_MASCOTS.map((m) => (
                      <button
                        key={m.id}
                        type="button"
                        onClick={() => setSimMascotId(m.id)}
                        className={`rounded-full px-2.5 py-1 text-[11px] font-semibold transition-all ${
                          simItem.id === m.id
                            ? "bg-[#16A34A] text-white shadow-2xs"
                            : "bg-[#F1F8F4] text-[#253858] hover:bg-[#DCFCE7]"
                        }`}
                      >
                        {lang === "ar" ? m.nameAr : m.nameEn}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* =================================================================
            SECTION 1: SUBSCRIPTION-PLAN MASCOTS (Reference Image 1)
            ================================================================= */}
        <section
          id="subscription-mascots"
          className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8"
        >
          <div className="flex flex-col justify-between gap-4 border-b border-[#DCEEE3] pb-6 md:flex-row md:items-end">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full bg-[#ECFDF3] px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#16A34A]">
                Reference Source 01 • Subscription Tiers
              </span>
              <h2 className="mt-3 font-display text-2xl font-extrabold tracking-tight text-[#0F1D3A] sm:text-3xl">
                Subscription-Plan Mascots{" "}
                <span className="font-arabic text-xl font-bold text-[#16A34A]" dir="rtl">
                  (باقات هيسي التعليمية)
                </span>
              </h2>
              <p className="mt-2 max-w-2xl text-sm text-[#475569]">
                Four distinct holographic pedestal mascots representing Individual, Pro, Family,
                and Group learning plans. Move your cursor over any mascot to see smooth 60fps
                3D visor & eye tracking, or click to trigger a damped spring reaction.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-[#334E68]">
              <span className="rounded-lg border border-[#DCEEE3] bg-white px-3 py-1.5">
                60 FPS Pointer Tracking & Spring Impulse
              </span>
            </div>
          </div>

          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {SUBSCRIPTION_MASCOTS.map((item, idx) => (
              <MascotCard
                key={item.id}
                item={item}
                index={idx}
                lang={lang}
                onInspect={setInspectedMascot}
              />
            ))}
          </div>
        </section>

        {/* =================================================================
            SECTION 2: EMOTIONAL STATE MASCOTS (Reference Image 2)
            ================================================================= */}
        <section
          id="emotional-mascots"
          className="scroll-mt-20 border-y border-[#DCEEE3] bg-gradient-to-b from-white via-[#F8FCFA] to-white py-16"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            {/* Reference Image 2 Authentic Section Banner Header */}
            <div className="flex flex-wrap items-center justify-between gap-6 rounded-3xl border border-[#DCEEE3] bg-[#F7FCF9] px-6 py-5 shadow-2xs">
              <div className="flex flex-wrap items-center gap-4">
                <HesiBrandMark size={54} />
                <span className="font-display text-4xl font-extrabold tracking-tight text-[#0F1D3A]">
                  Hesi
                </span>
                <span className="h-11 w-px bg-[#CBD5E1]" aria-hidden="true" />
                <div dir="rtl" className="font-arabic">
                  <h2 className="text-2xl font-extrabold text-[#0F1D3A]">تعبيرات هيسي</h2>
                  <p className="text-sm font-semibold text-[#334E68]">
                    كل لحظة ... شعور مختلف
                  </p>
                </div>
              </div>

              <div className="max-w-md text-xs leading-relaxed text-[#475569]">
                <strong className="text-[#0F1D3A]">Emotionally Intelligent 60 FPS Motion:</strong>{" "}
                Each emotional state runs a unique multi-joint rig — from{" "}
                <em>Sleepy (نايم)</em>’s gentle respiration and rising Z stream to{" "}
                <em>Anxious (قلقان)</em>’s calming mint reassurance aura.
              </div>
            </div>

            {/* 3x2 Grid matching Reference Image 2 */}
            <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {EMOTIONAL_MASCOTS.map((item, idx) => (
                <MascotCard
                  key={item.id}
                  item={item}
                  index={idx + 4}
                  lang={lang}
                  onInspect={setInspectedMascot}
                />
              ))}
            </div>
          </div>
        </section>

        {/* =================================================================
            SECTION 3: INTERACTIVE LEARNER SCENARIO & 60FPS LAYER SIMULATOR
            ================================================================= */}
        <section
          id="scenario-simulator"
          className="mx-auto max-w-7xl scroll-mt-20 px-4 py-16 sm:px-6 lg:px-8"
        >
          <div className="rounded-[32px] border border-[#BFE8D1] bg-white p-6 shadow-[0_18px_45px_-16px_rgba(15,29,58,0.08)] sm:p-10">
            <div className="max-w-3xl">
              <span className="inline-flex items-center gap-2 rounded-full bg-[#ECFDF3] px-3 py-1 text-xs font-bold uppercase tracking-wider text-[#16A34A]">
                Interactive Sandbox • 60 FPS Rig & Layer Testing
              </span>
              <h2 className="mt-3 font-display text-2xl font-extrabold text-[#0F1D3A] sm:text-3xl">
                Simulate Real Learner Moments & Toggle Independent SVG Layers
              </h2>
              <p className="mt-2 text-sm text-[#475569]">
                Select any of the 10 Hesi states below to preview how Hesi responds at 60fps inside
                a live learning interface, and toggle individual SVG layers to verify how each joint
                is animated independently.
              </p>
            </div>

            {/* Scenario Buttons */}
            <div className="mt-6 flex flex-wrap gap-2">
              {ALL_MASCOTS.map((m) => {
                const active = m.id === simMascotId;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => {
                      setSimMascotId(m.id);
                      setSimLayers(DEFAULT_LAYERS);
                    }}
                    className={`inline-flex items-center gap-2 rounded-xl border px-3.5 py-2 text-xs font-bold transition-all focus-visible:ring-2 focus-visible:ring-[#16A34A] focus-visible:outline-none ${
                      active
                        ? "border-[#16A34A] bg-[#16A34A] text-white shadow-sm"
                        : "border-[#DCEEE3] bg-[#F7FCF9] text-[#0F1D3A] hover:border-[#86EFAC]"
                    }`}
                  >
                    <span>{m.nameEn}</span>
                    <span className="font-arabic opacity-90" dir="rtl">
                      ({m.nameAr})
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Simulator Stage + Layer Controls */}
            <div className="mt-8 grid items-center gap-8 lg:grid-cols-12">
              {/* Stage */}
              <div className="flex flex-col items-center rounded-3xl border border-[#D9EFE4] bg-gradient-to-b from-[#F4FAFC] via-[#F1F9FB] to-[#E8F7F0] p-6 lg:col-span-5">
                <div
                  onClick={triggerSimReaction}
                  className="aspect-square w-full max-w-[290px] cursor-pointer"
                >
                  <MascotRenderer
                    id={simItem.id}
                    layers={simLayers}
                    reactionTrigger={simReactionCount}
                  />
                </div>

                <div className="mt-2 flex w-full items-center justify-between gap-2">
                  <span className="text-xs font-semibold text-[#334E68]">
                    Motion: {simItem.reactionCue}
                  </span>
                  <button
                    type="button"
                    onClick={triggerSimReaction}
                    className="rounded-full bg-[#16A34A] px-3.5 py-1.5 text-xs font-bold text-white transition-colors hover:bg-[#15803D]"
                  >
                    ⚡ Play 60fps Impulse
                  </button>
                </div>
              </div>

              {/* Layer Toggles & Simulated App Prompt */}
              <div className="space-y-5 lg:col-span-7">
                {/* Simulated In-App Coaching Card */}
                <div className="rounded-2xl border border-[#BFE8D1] bg-[#F4FBF7] p-5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <MascotBadgeIcon
                        type={simItem.iconType}
                        accentColor={simItem.accentColor}
                      />
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="font-display text-lg font-extrabold text-[#0F1D3A]">
                            {simItem.nameEn} — {simItem.subtitleEn}
                          </h3>
                          <span
                            className="font-arabic text-base font-extrabold text-[#16A34A]"
                            dir="rtl"
                          >
                            {simItem.nameAr} ({simItem.subtitleAr})
                          </span>
                        </div>
                        <p className="text-xs text-[#475569]">{simItem.motionProfile}</p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid gap-3 sm:grid-cols-2">
                    <div className="rounded-xl border border-[#DCEEE3] bg-white p-3.5">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-[#16A34A]">
                        English Learner Prompt
                      </span>
                      <p className="mt-1 text-xs font-medium leading-relaxed text-[#0F1D3A]">
                        “{simItem.learnerToastEn}”
                      </p>
                    </div>
                    <div
                      dir="rtl"
                      className="rounded-xl border border-[#DCEEE3] bg-white p-3.5 font-arabic"
                    >
                      <span className="text-[11px] font-bold text-[#16A34A]">
                        رسالة هيسي للمتعلم
                      </span>
                      <p className="mt-1 text-sm font-semibold leading-relaxed text-[#0F1D3A]">
                        «{simItem.learnerToastAr}»
                      </p>
                    </div>
                  </div>
                </div>

                {/* Independent SVG Layer Toggles */}
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold uppercase tracking-wider text-[#334E68]">
                      Toggle Independent SVG Layers ({simItem.nameEn})
                    </h4>
                    <button
                      type="button"
                      onClick={() => setSimLayers(DEFAULT_LAYERS)}
                      className="text-xs font-semibold text-[#16A34A] hover:underline"
                    >
                      Reset Layers
                    </button>
                  </div>

                  <div className="mt-2.5 grid gap-2 sm:grid-cols-2">
                    {simItem.layers.map((layer) => {
                      const on = simLayers[layer.id];
                      return (
                        <button
                          key={layer.id}
                          type="button"
                          onClick={() => toggleSimLayer(layer.id)}
                          className={`flex items-center justify-between rounded-xl border px-3.5 py-2.5 text-left text-xs transition-all ${
                            on
                              ? "border-[#86EFAC] bg-white font-semibold text-[#0F1D3A] shadow-2xs"
                              : "border-[#E2E8F0] bg-[#F8FAFC] text-[#64748B] opacity-65"
                          }`}
                        >
                          <div>
                            <p className="font-bold">{layer.label}</p>
                            <p className="text-[11px] font-normal text-[#475569]">
                              {layer.description}
                            </p>
                          </div>
                          <span
                            className={`ml-2 shrink-0 rounded-md px-2 py-0.5 text-[10px] font-bold ${
                              on
                                ? "bg-[#16A34A] text-white"
                                : "bg-[#E2E8F0] text-[#475569]"
                            }`}
                          >
                            {on ? "ON" : "OFF"}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* =================================================================
            SECTION 4: ARCHITECTURAL TRANSPARENCY & 60 FPS MOTION SPEC
            ================================================================= */}
        <section
          id="layer-architecture"
          className="border-t border-[#DCEEE3] bg-white py-14"
        >
          <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            <div className="grid gap-6 md:grid-cols-3">
              <div className="rounded-2xl border border-[#DCEEE3] bg-[#F7FCF9] p-5">
                <h3 className="font-display text-base font-bold text-[#0F1D3A]">
                  1. 60 FPS Procedural Character Rigging
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#475569]">
                  A single shared{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    requestAnimationFrame
                  </code>{" "}
                  loop drives every visible mascot’s{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    [data-rig]
                  </code>{" "}
                  joints using GPU-composited{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    translate3d
                  </code>
                  ,{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    rotate
                  </code>
                  , and{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    scale3d
                  </code>{" "}
                  without triggering React re-renders.
                </p>
              </div>

              <div className="rounded-2xl border border-[#DCEEE3] bg-[#F7FCF9] p-5">
                <h3 className="font-display text-base font-bold text-[#0F1D3A]">
                  2. Secondary Follow-Through & Eye Life
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#475569]">
                  Props and hands lag behind the primary body curve with phase-shifted inertia:
                  Pro’s gold tassel swings as a multi-harmonic pendulum, Proud’s cape billows in
                  the wind, Sleepy’s Z letters spiral and fade continuously, and the optical eye
                  sensor blinks and scans book lines naturally.
                </p>
              </div>

              <div className="rounded-2xl border border-[#DCEEE3] bg-[#F7FCF9] p-5">
                <h3 className="font-display text-base font-bold text-[#0F1D3A]">
                  3. Interactive Spring Physics & Off-Screen Pause
                </h3>
                <p className="mt-2 text-xs leading-relaxed text-[#475569]">
                  Pointer tracking and tap reactions use a damped harmonic spring solver (
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    k=180, c=12
                  </code>
                  ) for organic bounce and settle, while{" "}
                  <code className="rounded bg-[#E2F2EA] px-1 py-0.5 text-[#0D7A3E]">
                    IntersectionObserver
                  </code>{" "}
                  skips off-screen mascots automatically.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="border-t border-[#DCEEE3] bg-[#0F1D3A] py-10 text-white">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-4 px-4 sm:flex-row sm:px-6 lg:px-8">
          <div className="flex items-center gap-3">
            <HesiBrandMark size={38} />
            <div>
              <span className="font-display text-lg font-extrabold tracking-tight text-white">
                Hesi
              </span>
              <span className="mx-2 text-white/30">|</span>
              <span className="font-arabic text-sm font-bold text-[#86EFAC]" dir="rtl">
                تعبيرات هيسي — كل لحظة ... شعور مختلف
              </span>
            </div>
          </div>
          <p className="text-xs text-[#94A3B8]">
            60 FPS Procedural Character Rig • Subscription Plans (4) & Emotional States (6)
          </p>
        </div>
      </footer>

      {/* Interactive Layer & Motion Inspector Modal */}
      <LivePlaygroundModal
        item={inspectedMascot}
        lang={lang}
        onClose={() => setInspectedMascot(null)}
        onSelectMascot={(m) => setInspectedMascot(m)}
      />
    </div>
  );
}
